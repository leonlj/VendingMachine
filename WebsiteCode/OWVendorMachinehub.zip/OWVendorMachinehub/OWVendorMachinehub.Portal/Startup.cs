﻿using Microsoft.Owin;
using Owin;
using System.Web;

[assembly: OwinStartupAttribute(typeof(OWVendorMachineHub.Portal.Startup))]
namespace OWVendorMachineHub.Portal
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            AppConfig.LoadConfig();
            ConfigureAuth(app);
        }
    }
}
