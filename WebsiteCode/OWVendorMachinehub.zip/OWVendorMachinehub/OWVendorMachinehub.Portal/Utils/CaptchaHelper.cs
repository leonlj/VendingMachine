﻿using System;
using System.Linq;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Security.Cryptography;

namespace OWVendorMachineHub.Portal.Utils
{

    public class CaptchaHelper
    {
        /// <summary>
        /// 目标图片高度
        /// </summary>
        private const int IMG_HEIGHT = 30;
        /// <summary>
        /// 目标图片的宽度
        /// </summary>
        private const int IMG_WIDTH = 80;
        /// <summary>
        /// 验证码长度
        /// </summary>
        private const int CAPT_LENGH = 4;
        /// <summary>
        /// 验证码中所有可能出现字符
        /// </summary>
        private const string CAPT_SOURCE_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ123456789";
        /// <summary>
        /// 干扰直线的画笔宽度
        /// </summary>
        private const float PEN_WIDTH = 1.5f;
        /// <summary>
        /// 验证码字符的字体大小
        /// </summary>
        private const int FONT_SIZE = 18;
        /// <summary>
        /// 干扰线的数目
        /// </summary>
        private const int LINES_COUNT = 13;
        /// <summary>
        /// 图片背景色
        /// </summary>
        private Color BACK_COLOR = Color.DarkGray;
        /// <summary>
        /// 所有可能出现的字体
        /// </summary>
        private string[] FONT_FAMILIES = new[] { "Calibri", "Verdana", "Times New Roman" };
        /// <summary>
        /// 所有可能使用的颜色
        /// </summary>
        private Color[] FONT_COLORS = new Color[] { Color.Green, Color.Gray, Color.Brown };


        public string GetCaptchaString()
        {
            string randomText = GenerateRandomText(CAPT_LENGH);
            // GetMd5Hash(randomText);
            return randomText;

        }
        /// <summary>
        /// 生成验证码图片
        /// </summary>
        /// <param name="hashValue">验证字符串的哈希值</param>
        /// <returns></returns>
        public Bitmap GetCaptchaImage(string hashValue)
        {
            //生成随机字符串

            Random rnd = new Random();
            //背景色渐变角度
            float orientationAngle = rnd.Next(0, 359);
            //随机选取验证码字体
            string familyName = FONT_FAMILIES[rnd.Next(0, FONT_FAMILIES.Length)];
            //随机选取验证码字体颜色
            Color foreColor = FONT_COLORS[rnd.Next(0, FONT_COLORS.Length)];
            Bitmap bmpOut = new Bitmap(IMG_WIDTH, IMG_HEIGHT);

            using (Graphics graphics = Graphics.FromImage(bmpOut))
            {
                using (LinearGradientBrush gradientBrush = new LinearGradientBrush(new Rectangle(0, 0, IMG_WIDTH, IMG_HEIGHT),
                                                            Color.White, Color.DarkGray, orientationAngle))
                {


                    //绘制渐变背景色
                    graphics.FillRectangle(gradientBrush, 0, 0, IMG_WIDTH, IMG_HEIGHT);
                    //绘制干扰线条
                    DrawRandomLines(graphics, foreColor, PEN_WIDTH);
                    //绘制验证字符
                    graphics.DrawString(hashValue, new Font(familyName, 18), new SolidBrush(foreColor), 0, 2);
                    //计算哈希值

                    return bmpOut;
                }
            }



        }


        /// <summary>
        /// 画干扰线
        /// </summary>
        /// <param name="graphics">目标图形</param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <param name="penColor"></param>
        /// <param name="penWidth"></param>
        private void DrawRandomLines(Graphics graphics, Color penColor, float penWidth)
        {
            Random rnd = new Random();
            using (Pen pen = new Pen(penColor, penWidth))
            {
                for (int i = 0; i < LINES_COUNT; i++)
                {
                    //随机生成直线起始点和终止点坐标
                    graphics.DrawLine(pen, rnd.Next(0, IMG_WIDTH), rnd.Next(0, IMG_HEIGHT),
                                    rnd.Next(0, IMG_WIDTH), rnd.Next(0, IMG_HEIGHT));
                }
            }

        }

        /// <summary>
        /// 获得验证码的哈希值
        /// </summary>
        /// <param name="source">验证码</param>
        /// <returns></returns>
        public string GetMd5Hash(string source)
        {

            ASCIIEncoding encoding = new ASCIIEncoding();
            //都转化为大写字符，不区分大小写
            byte[] bytes = encoding.GetBytes(source.ToUpper());
            using (HashAlgorithm md5Hasher = MD5.Create())
            {
                return BitConverter.ToString(md5Hasher.ComputeHash(bytes));
            }
        }


        /// <summary>
        /// 生成随机字符串
        /// </summary>
        /// <param name="textLength">要生成的字符串长度</param>
        /// <returns></returns>
        public static string GenerateRandomText(int textLength)
        {
            Random random = new Random();
            string result = new string(Enumerable.Repeat(CAPT_SOURCE_CHARS, textLength)
                  .Select(s => s[random.Next(s.Length)]).ToArray());
            return result;
        }
    }

}