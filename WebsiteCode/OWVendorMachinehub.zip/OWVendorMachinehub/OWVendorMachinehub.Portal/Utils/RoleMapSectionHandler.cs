﻿using System.Configuration;
using System.Xml;
using System.Collections.Generic;

namespace OWVM.WEB.Authorize
{
    public class RoleMapSectionHandler : IConfigurationSectionHandler
    {
        public object Create(object parent, object configContext, XmlNode section)
        {
            Dictionary<string, string[]> roleMaps = new Dictionary<string, string[]>();
            foreach (XmlNode item in section.ChildNodes)
            {
                if (item.Name == "roleMap" && item.Attributes["url"] != null && item.Attributes["role"] != null)
                {
                    string url = item.Attributes["url"].Value;
                    string[] roles = item.Attributes["role"].Value.Split(',');
                    if (!roleMaps.ContainsKey(url.ToUpper()))
                        roleMaps.Add(url.ToUpper(), roles);
                    else
                    {
                        roleMaps[url.ToUpper()] = roles;
                    }
                }
            }
            return roleMaps;
        }
    }
}