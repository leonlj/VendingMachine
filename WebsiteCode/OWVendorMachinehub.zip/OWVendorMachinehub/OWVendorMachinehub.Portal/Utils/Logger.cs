﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OWVendorMachineHub.Portal.Utils;
using System.IO;
using System.Text;
using System.Threading;

namespace OWVendorMachineHub.Portal.Utils
{
    public class Logger
    {
        private Queue<OWVMLog> _logQueue = null;
        private StreamWriter _sw = null;
        private string _logFileDir = null;
        private string _logFilePreFix = null;
        private int _logLines = 0;

        private Thread _logThread = null;
        private int _logThreadInterval = 0;
        private int _maxLogLines = 0;

        public Logger(string logDir, string logFilePrefix = "owvm_", int interval = 3000, int maxLogLines = 10000)
        {
            _logQueue = new Queue<OWVMLog>();
            _logFileDir = logDir;
            _logFilePreFix = logFilePrefix;
            _logThreadInterval = interval;
            _maxLogLines = maxLogLines;

            _sw = GetNewStreamWriter();

            _logThread = new Thread(LogCore);
            _logThread.Start();
        }


        public void Log(OWVMLog log)
        {
            _logQueue.Enqueue(log);

            //if (_logThread.ThreadState != ThreadState.Running)
            //{
            //    lock (_logThread)
            //    {
            //        if (_logThread.ThreadState != ThreadState.Running)
            //        {
            //            _logThread.Start();
            //        }
            //    }
            //}
        }


        private void LogCore()
        {
            while (true)
            {
                if (_logQueue.Count > 0)
                {
                    var log = _logQueue.Dequeue();
                    if (log != null)
                    {
                        _sw.WriteLine(log.ToString());
                        _sw.Flush();
                        _logLines++;

                        if (_logLines > _maxLogLines)
                        {
                            _sw.Close();
                            _sw = null;
                            _logLines = 0;
                            _sw = GetNewStreamWriter();
                        }
                    }
                }
                else
                {
                    Thread.Sleep(_logThreadInterval);
                }
            }
        }


        private StreamWriter GetNewStreamWriter()
        {
            string fileName = string.Format("{0}\\{1}{2:yyyyMMddhhmmss}.log", _logFileDir.Trim('\\'), _logFilePreFix, DateTime.Now.ToOWVMUniversivalTime().ToOWVMLocalTime());
            return new StreamWriter(fileName, true, Encoding.UTF8);
        }


    }

    public class OWVMLog
    {
        public DateTime LogTime { get; set; }
        public string LogContent { get; set; }

        public OWVMLog() { }

        public OWVMLog(string msg)
        {
            LogContent = msg;
            LogTime = DateTime.Now.ToOWVMUniversivalTime().ToOWVMLocalTime();
        }

        public override string ToString()
        {
            return string.Format("{0:yyyy-MM-dd HH:mm:ss}\t{1}", LogTime, LogContent);
        }
    }
}