﻿using OWVendorMachineHub.Portal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;

namespace OWVendorMachineHub.Portal.Utils
{
    public class OWVMAuthorizeAttribute : AuthorizeAttribute
    {
        private string _roles;
        private string[] _rolesSplit = new string[0];
        private readonly object _typeId = new object();
        private string _users;
        private string[] _usersSplit = new string[0];

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            if (httpContext == null)
            {
                throw new ArgumentNullException("httpContext");
            }
            //IPrincipal user = httpContext.User;

            //if (!user.Identity.IsAuthenticated && httpContext.Session[AppConfig.SESSION_USERI_IDENTITY] != null)
            //{
            var user = httpContext.Session[AppConfig.SESSION_USERI_IDENTITY] as OWVMUserModel;
            //}


            if (!user.Identity.IsAuthenticated)
            {
                return false;
            }
            if ((this._usersSplit.Length > 0) && !this._usersSplit.Contains<string>(user.Identity.Name, StringComparer.OrdinalIgnoreCase))
            {
                return false;
            }
            if ((this._rolesSplit.Length > 0) && !this._rolesSplit.Any<string>(new Func<string, bool>(user.IsInRole)))
            {
                return false;
            }
            return true;
        }


        protected static string[] SplitString(string original)
        {
            if (string.IsNullOrEmpty(original))
            {
                return new string[0];
            }
            return (from piece in original.Split(new char[] { ',' })
                    let trimmed = piece.Trim()
                    where !string.IsNullOrEmpty(trimmed)
                    select trimmed).ToArray<string>();
        }

        public new string Roles
        {
            get
            {
                return (this._roles ?? string.Empty);
            }
            set
            {
                this._roles = value;
                this._rolesSplit = SplitString(value);
            }
        }

        public override object TypeId
        {
            get
            {
                return this._typeId;
            }
        }

        public new string Users
        {
            get
            {
                return (this._users ?? string.Empty);
            }
            set
            {
                this._users = value;
                this._usersSplit = SplitString(value);
            }
        }

    }
}