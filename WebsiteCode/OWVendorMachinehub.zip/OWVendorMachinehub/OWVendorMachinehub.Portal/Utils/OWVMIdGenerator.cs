﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Utils
{
    public class OWVMIdGenerator
    {
        private static Random _r = new Random();
        public static string NewOrderNum()
        {
            long orderNumberPart1 = long.Parse(string.Format("{0:yyyyMMddHHmmss}", DateTime.UtcNow));
            string orderNumber = OWVMConvert.To64(orderNumberPart1) + OWVMConvert.To64(_r.Next(40, 900));
            return orderNumber;
        }
    }


    public class OWVMConvert
    {
        private const string BASE_CHAR = "ABCDEFGHIJKLMNOPQRSTUVWXYZ-0123456789_abcdefghijklmnopqrstuvwxyz";

        public static string To64(long num)
        {
            string str = "";
            while (num > 0)
            {
                long cur = (long)num % BASE_CHAR.Length;
                str = BASE_CHAR[(int)cur] + str;
                num = num / BASE_CHAR.Length;
            }
            return str;
        }
    }
}