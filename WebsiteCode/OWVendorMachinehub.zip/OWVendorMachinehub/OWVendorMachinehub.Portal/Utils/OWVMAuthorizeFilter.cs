﻿using System.Linq;
using System.Web.Mvc;
using Microsoft.AspNet.Identity.Owin;
using System.Web;
using System;
using System.Text;
using OWVendorMachineHub.Portal.Models;
using System.Collections.Generic;
using OWVendorMachineHub.Portal.Utils;
using OWVendorMachineHub.Portal.Services;
using OWVendorMachineHub.Portal;

namespace ARC.WEB.Authorize
{
    public class OWVMAuthorizeFilter : FilterAttribute, IAuthorizationFilter
    {

        private UserInfoManager _userManager;
        public UserInfoManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.Current.GetOwinContext().GetUserManager<UserInfoManager>();
            }
            private set
            {
                _userManager = value;
            }
        }


        public void OnAuthorization(AuthorizationContext filterContext)
        {
            AutoLogin(filterContext.HttpContext);
            Authorize(filterContext);
        }

        
        /// <summary>
        /// 自动登录
        /// </summary>
        /// <param name="httpContext"></param>
        private void AutoLogin(HttpContextBase httpContext)
        {
            var session = httpContext.Session[AppConfig.SESSION_USERI_IDENTITY];
            var cookie = httpContext.Request.Cookies.Get(AppConfig.COOKIE_USER_SECURITY_STAMP);

            if (session == null && cookie != null && cookie.Value != null)
            {
                string stamp = Encoding.UTF8.GetString(Convert.FromBase64String(cookie.Value));
                string[] kvs = stamp.Split('+');
                if (kvs.Length == 2)
                {
                    var userInfo = UserManager.FindByStamp(kvs[1]);
                    if (userInfo != null && !userInfo.IsDelete)
                    {
                        httpContext.Session[AppConfig.SESSION_USERI_IDENTITY] = new OWVMUserModel(
                            new OWVMIdentityModel(userInfo.Id, userInfo.Email, userInfo.UserName, userInfo.TrueName, userInfo.GetUserRoleNames()));
                    }
                }
            }
        }

        /// <summary>
        /// 请求权限验证
        /// </summary>
        /// <param name="filterContext"></param>
        private void Authorize(AuthorizationContext filterContext)
        {
            string action = filterContext.ActionDescriptor.ActionName;
            string controller = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
            string rawUrl = string.Format("/{0}/{1}", controller, action).ToUpper();

            if (AppConfig.RoleMapCollection.ContainsKey(rawUrl))
            {
                string[] allowedRoles = AppConfig.RoleMapCollection[rawUrl];
                if (!allowedRoles.Contains("*"))
                {
                    var user = filterContext.HttpContext.Session[AppConfig.SESSION_USERI_IDENTITY] as OWVMUserModel;

                    if (user != null && user.Identity != null)
                    {
                        bool isInRole = allowedRoles.Any(ar => user.Identity.IsInRole(ar));
                        if (isInRole)
                            return;
                    }

                    if (filterContext.RequestContext.HttpContext.Request.IsAjaxRequest())
                    {
                        filterContext.Result = new JsonResult { Data = new { Result = "-1", Message = "对不起，您的权限不足！" } };
                    }
                    else
                    {
                        string redirectUrl = filterContext.HttpContext.Request.Url.ToString();
                        filterContext.Result = new RedirectResult(string.Concat(AppConfig.LogonUrl, "?returnUrl=", redirectUrl));
                    }
                }
            }
        }
    }
}