﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Utils
{
    public static class MoenyExtensions
    {
        public static double MoneyAmount(this string moneyString)
        {
            double money = 0;
            if (!string.IsNullOrEmpty(moneyString))
            {
                var newMoneyString = moneyString.Replace("$", "").Replace("¥", "").Replace(",", "").Replace(" ", "");
                money = double.Parse(newMoneyString);

            } return money;
        }
    }
}