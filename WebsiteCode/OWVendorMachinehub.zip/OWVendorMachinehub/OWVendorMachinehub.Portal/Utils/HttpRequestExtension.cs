﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Utils
{
    public static class HttpRequestExtension
    {
        /// <summary>
        /// 判断是否为微信发出请求
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public static bool IsWeChatRequest(this HttpRequestBase request)
        {
            if (request != null && ((request.UserAgent != null && request.UserAgent.IndexOf("MicroMessenger") > 0) || (request.Headers["ARC_UA"] != null && request.Headers["ARC_UA"].IndexOf("MicroMessenger") > 0))
                )
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 判断是否为移动浏览器发出的请求
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public static bool IsMobileRequest(this HttpRequestBase request)
        {
            if (request != null && ((request.UserAgent != null && request.UserAgent.IndexOf("Mobile") > 0) || (request.Headers["ARC_UA"] != null && request.Headers["ARC_UA"].IndexOf("MicroMessenger") > 0)))
            {
                return true;
            }
            return false;
        }
    }
}