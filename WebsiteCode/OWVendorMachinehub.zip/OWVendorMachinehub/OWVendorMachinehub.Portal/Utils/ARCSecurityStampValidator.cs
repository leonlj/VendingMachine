﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security.Cookies;
using OWVendorMachineHub.Portal.Db.Models;
using OWVendorMachineHub.Portal.Models;
using OWVendorMachineHub.Portal.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;

namespace OWVendorMachineHub.Portal.Utils
{
    public static class OWVMSecurityStampValidator
    {
        public static Func<CookieValidateIdentityContext, Task> OnValidateIdentity(TimeSpan validateInterval, Func<UserInfoManager, UserInfo, Task<ClaimsIdentity>> regenerateIdentity)
        {
            return OnARCValidateIdentity(validateInterval, regenerateIdentity);
        }


        public static Func<CookieValidateIdentityContext, Task> OnARCValidateIdentity(TimeSpan validateInterval
            , Func<UserInfoManager, UserInfo, Task<ClaimsIdentity>> regenerateIdentityCallback)
        {
            HttpContext httpContext = HttpContext.Current;

            return async delegate(CookieValidateIdentityContext context)
            {
                DateTimeOffset utcNow = DateTimeOffset.UtcNow;
                if ((context.Options != null) && (context.Options.SystemClock != null))
                {
                    utcNow = context.Options.SystemClock.UtcNow;
                }
                DateTimeOffset? issuedUtc = context.Properties.IssuedUtc;
                bool validate = !issuedUtc.HasValue;
                if (issuedUtc.HasValue)
                {
                    TimeSpan span = utcNow.Subtract(issuedUtc.Value);
                    validate = span > validateInterval;
                }
                if (validate)
                {
                    UserInfoManager userManager = context.OwinContext.GetUserManager<UserInfoManager>();
                    string userId = context.Identity.GetUserId();
                    if ((userManager != null) && (userId != null))
                    {
                        UserInfo user = await userManager.FindByIdAsync(userId);
                        bool reject = true;
                        if ((user != null) && userManager.SupportsUserSecurityStamp)
                        {
                            string str = context.Identity.FindFirstValue("AspNet.Identity.SecurityStamp");
                            string introduced19 = await userManager.GetSecurityStampAsync(userId);
                            if (str == introduced19)
                            {
                                reject = false;
                                if (regenerateIdentityCallback != null)
                                {
                                    ClaimsIdentity asyncVariable0 = await regenerateIdentityCallback(userManager, user);
                                    if (asyncVariable0 != null)
                                    {
                                        context.OwinContext.Authentication.SignIn(new ClaimsIdentity[] { asyncVariable0 });
                                       
                                        //httpContext.Session[AppConfig.SESSION_USERI_IDENTITY] = HttpContext.Current.User;
                                    }
                                }
                            }
                        }
                        if (reject)
                        {
                            context.RejectIdentity();
                            context.OwinContext.Authentication.SignOut(new string[] { context.Options.AuthenticationType });
                            //httpContext.Session.Remove(AppConfig.SESSION_USERI_IDENTITY);
                        }
                    }
                }
            };
        }


    }


}