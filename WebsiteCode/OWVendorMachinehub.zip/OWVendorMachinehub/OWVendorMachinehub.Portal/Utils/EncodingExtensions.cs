﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Utils
{
    public static class EncodingExtensions
    {
        public static byte[] ToUTF8BOM(this byte[] content)
        {
            byte[] bom = content;
            if (content != null)
            {
                bom = new byte[content.Length + 3];

                content.CopyTo(bom, 3);
                bom[0] = 0xef;
                bom[1] = 0xbb;
                bom[2] = 0xbf;
            }
            return bom;
        }
    }
}