﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Utils
{
    public static class DateTimeExtensions
    {
        public static DateTime ToOWVMLocalTime(this DateTime dateTime, int timeZone = +8)
        {
            return dateTime.AddHours(timeZone);
        }

        public static DateTime ToOWVMUniversivalTime(this DateTime datetime)
        {
            return datetime.ToUniversalTime();
        }

        public static string ToOWVMTimeString(this DateTime datetime)
        {
            return datetime.ToString("yyyy-MM-dd HH:mm:ss");
        }

        public static string ToOWVMDateString(this DateTime datetime)
        {
            return datetime.ToString("yyyy-MM-dd");
        }


        public static bool IsOWVMNULLDate(this DateTime datetime)
        {
            return datetime.CompareTo(new DateTime(1970, 1, 1)) <= 0;
        }
    }
}