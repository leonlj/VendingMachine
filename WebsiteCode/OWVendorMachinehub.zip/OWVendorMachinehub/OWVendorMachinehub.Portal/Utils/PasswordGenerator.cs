﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Utils
{
    public class PasswordGenerator
    {
        public static string GenerateNewPassword()
        {
            return CaptchaHelper.GenerateRandomText(8);
        }
    }
}