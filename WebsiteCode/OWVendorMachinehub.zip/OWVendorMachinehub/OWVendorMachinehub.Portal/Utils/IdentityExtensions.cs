﻿using OWVendorMachineHub.Portal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using OWVendorMachineHub.Portal.Db.Models;
using OWVendorMachineHub.Portal.Services;

namespace OWVendorMachineHub.Portal.Utils
{
    public static class IdentityExtensions
    {

        static IdentityExtensions()
        {
            UserManager = HttpContext.Current.GetOwinContext().Get<UserInfoManager>();
        }

        public static UserInfoManager UserManager
        {
            get;
            private set;
        }


        public static IList<string> GetUserRoles(this System.Security.Principal.IIdentity identity)
        {
            IList<string> userRoles = new List<string>();
            var userId = identity.GetUserId();
            if (userId != null)
            {
                userRoles = UserManager.GetRoles(userId);
            }
            return userRoles;
        }


        public static IList<string> GetUserRoleNames(this UserInfo userInfo)
        {
            IList<string> userRoles = new List<string>();
            if (userInfo != null)
            {
                foreach (var item in userInfo.Roles)
                {
                    userRoles.Add(AppConfig.UserRoles[item.RoleId]);
                }
            }
            return userRoles;
        }



        public static int GetMaxAuthorizationLevel(this System.Security.Principal.IIdentity identity)
        {
            var roles = identity.GetUserRoles();
            return GetMaxAuthorizationLevel(roles);
        }

        public static int GetMaxAuthorizationLevel(this OWVMIdentityModel identity)
        {
            var roles = identity.GetUserRoles();
            return GetMaxAuthorizationLevel(roles);
        }

        public static int GetMaxAuthorizationLevel(this UserInfo userInfo)
        {
            var roles = userInfo.GetUserRoleNames();
            return GetMaxAuthorizationLevel(roles);
        }

        private static int GetMaxAuthorizationLevel(ICollection<string> roles)
        {
            if (roles != null && roles.Count > 0)
            {

                string[] roleIds = AppConfig.UserRoles.Where(r => roles.Contains(r.Value)).Select(r => r.Key).ToArray();
                var roleLevel = AppConfig.RoleLevels.Where(l => roleIds.Contains(l.Key)).OrderByDescending(r => r.Value).FirstOrDefault().Value;
                return roleLevel;
            }
            return 0;
        }




        public static UserInfo ToUserInfo(this UserInfoViewModelBase model)
        {
            if (model == null)
                return null;

            string newId = Guid.NewGuid().ToString();
            var user = new UserInfo
            {
                Id = newId,
                UserName = model.Name,
                Email = model.Email,
                PhoneNumber = model.Telphone,
                TrueName = model.Name,
                WeChatId = model.WeChatId,
                CreateUser = newId,
                CreateTime = DateTime.Now.ToOWVMUniversivalTime(),
                UpdateTime = DateTime.Now.ToOWVMUniversivalTime(),
                UpdateUser = newId,
                UserStatus = UserStatus.Activated
            };
            return user;
        }

        public static UserInfoListViewModel ToUserInfoListViewModel(this UserInfo userInfo, Guid[] providers = null)
        {
            if (userInfo == null)
                return null;

            var model = new UserInfoListViewModel
            {
                UserId = userInfo.Id,
                TrueName = userInfo.TrueName,
                Email = userInfo.Email,
                Phone = userInfo.PhoneNumber,
                CreateTime = userInfo.CreateTime.ToOWVMLocalTime().ToOWVMTimeString(),
                UpdateTime = userInfo.UpdateTime.ToOWVMLocalTime().ToOWVMTimeString(),
                Status = userInfo.GetStatusString(),
                WeChatId = userInfo.WeChatId == null ? null : userInfo.WeChatId.Replace("微信号（可不填）", ""),
                IsDelete = userInfo.IsDelete ? 1 : 0
            };

            string[] roles = userInfo.Roles.Join(AppConfig.UserRoles, ur => ur.RoleId, r => r.Key, (ur, r) => r.Value).ToArray();
            model.Roles = string.Join(",", roles).Trim(',');
            return model;
        }

        public static UserInfoListViewModel ToUserInfoListViewModel(this UserInfo userInfo)
        {
            if (userInfo == null)
                return null;

            var model = new UserInfoListViewModel
            {
                UserId = userInfo.Id,
                TrueName = userInfo.TrueName,
                Email = userInfo.Email,
                Phone = userInfo.PhoneNumber,
                CreateTime = userInfo.CreateTime.ToOWVMLocalTime().ToOWVMTimeString(),
                UpdateTime = userInfo.UpdateTime.ToOWVMLocalTime().ToOWVMTimeString(),
                Status = userInfo.GetStatusString(),
                WeChatId = userInfo.WeChatId == null ? null : userInfo.WeChatId.Replace("微信号（可不填）", ""),
                IsDelete = userInfo.IsDelete ? 1 : 0
            };

            string[] roles = null;

            roles = userInfo.Roles.Join(AppConfig.UserRoles, ur => ur.RoleId, r => r.Key, (ur, r) => r.Value).ToArray();

            model.Roles = string.Join(",", roles).Trim(',');
            return model;
        }

        public static EditUserViewModel ToEditUserViewModel(this UserInfo userInfo)
        {
            if (userInfo == null)
                return null;

            var model = new EditUserViewModel
            {
                UserId = userInfo.Id,
                Name = userInfo.TrueName,
                Email = userInfo.Email,
                Telphone = userInfo.PhoneNumber,
                WeChatId = userInfo.WeChatId
            };

            var salesKey = AppConfig.UserRoles.FirstOrDefault(ur => ur.Value == "销售人员").Key;
            var adminKey = AppConfig.UserRoles.FirstOrDefault(ur => ur.Value == "管理员").Key;

            foreach (var item in userInfo.Roles)
            {
                model.Roles += item.RoleId + ",";
            }

            model.Roles = model.Roles.Trim(',');
            return model;
        }




        public static string GetStatusString(this UserInfo userInfo)
        {
            if (userInfo == null)
                return null;
            if (userInfo.IsDelete)
                return "已禁用";

            switch (userInfo.UserStatus)
            {
                case UserStatus.UnActivated:
                    return "未激活";
                case UserStatus.Activated:
                    return "已启用";
                default:
                    return "未知";
            }
        }

        public static AddUserViewModel ToAddUserViewModel(this RegisterViewModel model)
        {
            if (model == null)
                return null;
            return new AddUserViewModel
            {

                Email = model.Email,
                Name = model.Name,
                Password = model.Password,
                Telphone = model.Telphone,
                WeChatId = model.WeChatId == null ? null : model.WeChatId.Replace("微信号（可不填）", "")
            };
        }

    }
}