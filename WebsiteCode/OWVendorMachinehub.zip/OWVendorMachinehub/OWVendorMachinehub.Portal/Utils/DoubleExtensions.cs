﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Models
{

    public static class DoubleExtensions
    {
        public static string ToARCMoneyString(this float money)
        {
            return money.ToString("C2").Replace("$", "");
        }

        public static string ToARCMoneyString(this double money)
        {
            return money.ToString("C2").Replace("$", "");
        }

        public static string FromMoneyString(this string moneyString)
        {
            if (!string.IsNullOrEmpty(moneyString))
                return moneyString.Replace("¥", "").Replace(",", "").Trim();
            return "";
        }
    }
}