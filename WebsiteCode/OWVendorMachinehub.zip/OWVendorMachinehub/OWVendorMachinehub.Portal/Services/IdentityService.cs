﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin;
using Microsoft.Owin.Security;
using System.Data.SqlClient;
using OWVendorMachineHub.Portal.Db;
using OWVendorMachineHub.Portal.Db.Models;

namespace OWVendorMachineHub.Portal.Services
{
    public class EmailService : IIdentityMessageService
    {
        public Task SendAsync(IdentityMessage message)
        {
            //AppConfig.EmailService.SendMail(new string[] { message.Destination }, null, message.Subject, message.Body);

            //return AppConfig.EmailService.SendEmailAsync(new string[] { message.Destination }, null, message.Subject, message.Body);
            // Plug in your email service here to send an email.
            return Task.FromResult(0);
        }
    }

    public class SmsService : IIdentityMessageService
    {
        public Task SendAsync(IdentityMessage message)
        {
            // Plug in your SMS service here to send a text message.
            return Task.FromResult(0);
        }
    }

    // Configure the application user manager used in this application. UserManager is defined in ASP.NET Identity and is used by the application.
    public class UserInfoManager : UserManager<UserInfo>
    {
        protected OWVMUserStore ARCUserStore { get; private set; }

        public UserInfoManager(IUserStore<UserInfo> store)
            : base(store)
        {
            ARCUserStore = store as OWVMUserStore;
        }

        public static UserInfoManager Create(IdentityFactoryOptions<UserInfoManager> options, IOwinContext context)
        {
            var manager = new UserInfoManager(new OWVMUserStore(context.Get<ApplicationDbContext>()));
            // Configure validation logic for usernames
            manager.UserValidator = new UserValidator<UserInfo>(manager)
            {
                AllowOnlyAlphanumericUserNames = false,
                RequireUniqueEmail = true

            };

            //密码强度验证逻辑
            manager.PasswordValidator = new PasswordValidator
            {
                RequiredLength = 6,
                RequireNonLetterOrDigit = false,//非数字和字母
                RequireDigit = false,//数字
                RequireLowercase = false,//小写字母
                RequireUppercase = false,//大写字母
            };



            // Configure user lockout defaults

            manager.UserLockoutEnabledByDefault = true;
            manager.DefaultAccountLockoutTimeSpan = TimeSpan.FromMinutes(5);
            manager.MaxFailedAccessAttemptsBeforeLockout = 5;

            // Register two factor authentication providers. This application uses Phone and Emails as a step of receiving a code for verifying the user
            // You can write your own provider and plug it in here.
            manager.RegisterTwoFactorProvider("Phone Code", new PhoneNumberTokenProvider<UserInfo>
            {
                MessageFormat = "Your security code is {0}"
            });
            manager.RegisterTwoFactorProvider("Email Code", new EmailTokenProvider<UserInfo>
            {
                Subject = "Security Code",
                BodyFormat = "Your security code is {0}"
            });
            manager.EmailService = new EmailService();
            manager.SmsService = new SmsService();
            var dataProtectionProvider = options.DataProtectionProvider;
            if (dataProtectionProvider != null)
            {
                manager.UserTokenProvider =
                    new DataProtectorTokenProvider<UserInfo>(dataProtectionProvider.Create("ASP.NET Identity"));
            }
            return manager;
        }


        public async Task<UserInfo> FindByPhoneAsync(string phone)
        {
            return await ARCUserStore.FindByPhoneAsync(phone);
        }

        public async Task<UserInfo> FindBySignature(string signature)
        {
            return await ARCUserStore.FindByiSignature(signature);
        }

        public UserInfo FindByStamp(string stamp)
        {
            return ARCUserStore.FindByStamp(stamp);
        }


        public async Task<List<UserInfo>> FindUsersByRoleId(string roleId)
        {
            return await ARCUserStore.FindUsersByRoleId(roleId);
        }

        public async Task<List<UserInfo>> FindUsersByRoleName(string roleName)
        {
            return await ARCUserStore.FindUsersByRoleName(roleName);
        }

    }

 

    public class OWVMUserStore : UserStore<UserInfo, RoleInfo, string, IdentityUserLogin, UserRole, IdentityUserClaim>, IUserStore<UserInfo>
    {
        public OWVMUserStore(DbContext context)
            : base(context)
        {

        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }

        public UserInfo FindByStamp(string stamp)
        {

            return base.Users.Include<UserInfo, ICollection<UserRole>>(u => u.Roles).Include<UserInfo, ICollection<IdentityUserClaim>>(u => u.Claims).Include<UserInfo, ICollection<IdentityUserLogin>>(u => u.Logins).FirstOrDefault<UserInfo>(u => u.SecurityStamp == stamp);

        }



        public override Task<UserInfo> FindByNameAsync(string userName)
        {
            return FindByPhoneOrEmailAsync(userName);
        }

        private async Task<UserInfo> FindByPhoneOrEmailAsync(string userName)
        {
            var userInfo = await (FindByPhoneAsync(userName)) ?? await (base.FindByEmailAsync(userName));
            return userInfo;
        }

        public Task<UserInfo> FindByPhoneAsync(string phone)
        {
            return base.GetUserAggregateAsync(u => u.PhoneNumber == phone);
        }

        public Task<UserInfo> FindByTrueNameAsync(string trueName)
        {
            return base.GetUserAggregateAsync(u => u.TrueName == trueName);
        }


        public Task<UserInfo> FindByiSignature(string signature)
        {
            return base.GetUserAggregateAsync(u => u.Signature == signature);
        }

        public Task<List<UserInfo>> FindUsersByRoleId(string roleId)
        {
            SqlParameter[] sqlParams = new SqlParameter[2];
            sqlParams[0] = new SqlParameter("@RoleId", roleId);
            sqlParams[1] = new SqlParameter("@IncludeDeleted", false) { DbType = System.Data.DbType.Boolean };
            var q = Context.Database.SqlQuery<UserInfo>("exec GetUsersByRoleId @RoleId,@IncludeDeleted", sqlParams);
            return q.ToListAsync();
        }

        public Task<List<UserInfo>> FindUsersByRoleName(string roleName)
        {
            SqlParameter[] sqlParams = new SqlParameter[2];
            sqlParams[0] = new SqlParameter("@RoleName", roleName);
            sqlParams[1] = new SqlParameter("@IncludeDeleted", false) { DbType = System.Data.DbType.Boolean };
            var q = Context.Database.SqlQuery<UserInfo>("exec GetUsersByRoleName @RoleName,@IncludeDeleted", sqlParams);
            return q.ToListAsync();
        }
    }

    // Configure the application sign-in manager which is used in this application.
    public class UserSignInManager : SignInManager<UserInfo, string>
    {
        public UserSignInManager(UserInfoManager userManager, IAuthenticationManager authenticationManager)
            : base(userManager, authenticationManager)
        {
        }

        public override Task<ClaimsIdentity> CreateUserIdentityAsync(UserInfo user)
        {
            return user.GenerateUserIdentityAsync((UserInfoManager)UserManager);
        }

        public static UserSignInManager Create(IdentityFactoryOptions<UserSignInManager> options, IOwinContext context)
        {
            return new UserSignInManager(context.GetUserManager<UserInfoManager>(), context.Authentication);
        }
    }


    public class RoleInfoManager : RoleManager<RoleInfo, string>
    {
        protected ARCRoleStore ARCRoleStore { get; private set; }

        public RoleInfoManager(IRoleStore<RoleInfo> roleStore)
            : base(roleStore)
        {
            ARCRoleStore = roleStore as ARCRoleStore;



        }

        // PASS CUSTOM APPLICATION ROLE AS TYPE ARGUMENT:
        public static RoleInfoManager Create(
            IdentityFactoryOptions<RoleInfoManager> options, IOwinContext context)
        {
            return new RoleInfoManager(
                new ARCRoleStore(context.Get<ApplicationDbContext>()));
        }



    }


    public class ARCRoleStore : RoleStore<RoleInfo, string, UserRole>, IQueryableRoleStore<RoleInfo, string>, IRoleStore<RoleInfo>
    {
        public ARCRoleStore(DbContext context)
            : base(context)
        {
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }
    }



    public class ARCPasswordHasher : IPasswordHasher
    {

        public string HashPassword(string password)
        {
            return null;
        }

        public PasswordVerificationResult VerifyHashedPassword(string hashedPassword, string providedPassword)
        {
            return PasswordVerificationResult.Success;
        }
    }

}
