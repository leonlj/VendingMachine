﻿using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin;
using OWVendorMachineHub.Portal.Db;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Services
{

    public class AppDbManager : OWVMDispose
    {
        protected ApplicationDbContext Context { get; private set; }
        public AppDbManager(ApplicationDbContext context)
        {
            this.Context = context;
        }

        protected override void Dispose(bool dispose)
        {
            Context.SaveChanges();
            base.Dispose(true);
        }
        
        public static T Create<T>(IdentityFactoryOptions<T> options, IOwinContext context) where T : AppDbManager
        {
            object tInstance = typeof(T).Assembly.CreateInstance(typeof(T).FullName, true, System.Reflection.BindingFlags.Default, null, new[] { new ApplicationDbContext() }, null, null);
            return tInstance as T;
        }
    }
}