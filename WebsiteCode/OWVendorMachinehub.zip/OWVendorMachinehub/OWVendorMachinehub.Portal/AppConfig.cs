﻿using OWVendorMachineHub.Portal.Db;
using OWVendorMachineHub.Portal.Models;
using OWVendorMachineHub.Portal.Services;
using OWVendorMachineHub.Portal.Utils;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace OWVendorMachineHub.Portal
{
    public class AppConfig
    {

        public const string SESSION_USERI_IDENTITY = "User_Identity";
        public const string COOKIE_USER_SECURITY_STAMP = ".AspNet.OWVMPortal";

        public static string LogonUrl { get; private set; }

        public static IotHubConfig IotHubConfig { get; private set; }

        public static void LoadConfig()
        {
            RoleMapCollection = ConfigurationManager.GetSection("roleMaps") as Dictionary<string, string[]>;
            LogonUrl = ConfigurationManager.AppSettings["LogonUrl"];
            LoadUserRoles();
            IotHubConfig = GetConfigObject<IotHubConfig>("IotHub:");
            UploadConfig = GetConfigObject<UploadConfig>("upload:");
        }

        public static UploadConfig UploadConfig { get; private set; }

        private static void LoadUserRoles()
        {
            UserRoles = new Dictionary<string, string>();
            RoleLevels = new Dictionary<string, int>();

            using (ApplicationDbContext context = new ApplicationDbContext())
            {
                var roles = context.Roles.ToList();
                foreach (var item in roles)
                {
                    UserRoles.Add(item.Id, item.Name);
                    RoleLevels.Add(item.Id, item.Level);
                }
            }
        }



        private static T GetConfigObject<T>(string configPrefix) where T : ConfigObject
        {
            Type configType = typeof(T);
            var asm = configType.Assembly;
            object configObject = asm.CreateInstance(configType.FullName);
            var configKeys = ConfigurationManager.AppSettings.AllKeys.Where(k => k.StartsWith(configPrefix)).ToArray();
            if (configKeys != null && configKeys.Length > 0)
            {
                foreach (var item in configKeys)
                {
                    object configValue = ConfigurationManager.AppSettings[item];
                    if (configObject != null)
                    {
                        var pi = configType.GetProperty(item.Replace(configPrefix, ""));
                        pi.SetValue(configObject, Convert.ChangeType(configValue, pi.PropertyType));
                    }
                }

            }
            return configObject as T;
        }

        public static Dictionary<string, string> UserRoles { get; private set; }

        public static Dictionary<string, int> RoleLevels { get; private set; }


        /// <summary>
        /// 用户角色及可访问页面映射集合
        /// </summary>
        public static Dictionary<string, string[]> RoleMapCollection { get; private set; }
    }

    public class IotHubConfig : ConfigObject
    {
        public string HostName { get; set; }
        public string RuleName { get; set; }
        public string RuleKey { get; set; }

        public override string ToString()
        {
            return string.Format("HostName={0};SharedAccessKeyName={1};SharedAccessKey={2}", HostName ?? "", RuleName ?? "", RuleKey ?? "");
        }
    }

    public class UploadConfig : ConfigObject
    {
        public string UploadUrlBase { get; set; }
        public string Directory { get; set; }
    }


    public abstract class ConfigObject { }
}