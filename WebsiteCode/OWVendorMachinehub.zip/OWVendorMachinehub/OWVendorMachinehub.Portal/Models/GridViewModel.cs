﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Models
{
    public class GridViewModel<TRowModel>
    {
        public int current { get; set; }
        public int rowCount { get; set; }
        public List<TRowModel> rows { get; set; }
        public int total { get; set; }
    }

    public class UserInfoListViewModel
    {
        public string UserId { get; set; }
        public string TrueName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Roles { get; set; }
        public string Status { get; set; }
        public string WeChatId { get; set; }
        public string CreateTime { get; set; }
        public string UpdateTime { get; set; }
        public int IsDelete { get; set; }
    }






    public class BootGridPagerModel
    {
        public int current { get; set; }
        public int rowCount { get; set; }
        public string sort { get; set; }
        public string searchPhrase { get; set; }
    }
}