﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OWVendorMachineHub.Portal.Utils;
using System.Web.Mvc;
using System.Threading.Tasks;

namespace OWVendorMachineHub.Portal.Models
{
    public class AjaxResult
    {
        public int Status { get; set; }
        public string Message { get; set; }
    }

    public class AjaxResult<T> : AjaxResult
    {
        public T Data { get; set; }
    }


    public class AjaxRedirectResult : AjaxResult
    {
        public string RedirectUrl { get; set; }

        public AjaxRedirectResult()
        {
            Status = 302;
        }

        public AjaxRedirectResult(string url)
            : this()
        {

            this.RedirectUrl = url;
        }
    }


    public class OWRedirectResult
    {
        public static ActionResult Redirect(string url, bool refresh = true)
        {
            if (HttpContext.Current.Request.IsAjaxRequest())
            {
                if (!refresh)
                {
                    return new JsonResult { Data = new AjaxRedirectResult(url) { Message = "请求客户端重定向页面" } };
                }
                else
                {
                    return new JsonResult { Data = new AjaxRedirectResult { Message = "请求客户端重刷新页面", Status = 303 } };
                }
            }
            else
            {
                return new RedirectResult(url);
            }
        }

         
    }
}