﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.Principal;

namespace OWVendorMachineHub.Portal.Models
{
    public class ExternalLoginConfirmationViewModel
    {
        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }

    public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }

    public class SendCodeViewModel
    {
        public string SelectedProvider { get; set; }
        public ICollection<System.Web.Mvc.SelectListItem> Providers { get; set; }
        public string ReturnUrl { get; set; }
        public bool RememberMe { get; set; }
    }

    public class VerifyCodeViewModel
    {
        [Required]
        public string Provider { get; set; }

        [Required]
        [Display(Name = "Code")]
        public string Code { get; set; }
        public string ReturnUrl { get; set; }

        [Display(Name = "Remember this browser?")]
        public bool RememberBrowser { get; set; }

        public bool RememberMe { get; set; }
    }

    public class ForgotViewModel
    {
        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }

    public class LoginViewModel
    {
        [Required]
        [Display(Name = "手机")]

        public string Email { get; set; }

        [Required]
        [Display(Name = "密码")]
        public string NewPassword { get; set; }

        [Display(Name = "记住我?")]
        public bool RememberMe { get; set; }
    }


    public class UserInfoViewModelBase
    {
        [Required]
        [Display(Name = "姓名")]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        [Display(Name = "邮箱")]
        public string Email { get; set; }

        [Required]
        [Phone]
        [Display(Name = "电话")]
        public string Telphone { get; set; }
        [Display(Name = "微信号")]
        public string WeChatId { get; set; }

        [Display(Name = "密码")]
        public virtual string Password { get; set; }

    }

    public class RegisterViewModel : UserInfoViewModelBase
    {

        [Required]
        [StringLength(100, ErrorMessage = "{0} 至少长度为 {2}位", MinimumLength = 6)]
        //[DataType(DataType.Password)]
        [Display(Name = "密码")]
        public override string Password
        {
            get
            {
                return base.Password;
            }
            set
            {
                base.Password = value;
            }
        }

        [DataType(DataType.Password)]
        [Display(Name = "确认密码")]
        [Compare("Password", ErrorMessage = "确认密码和密码不匹配")]
        public string ConfirmPassword { get; set; }


        //[Display(Name = "地址")]
        //public string Address { get; set; }
    }

    public class AddUserViewModel : UserRoleInfoViewModel
    {


    }

    public class UserRoleInfoViewModel : UserInfoViewModelBase
    {
        //[Required]
        [Display(Name = "用户角色")]
        public string Roles { get; set; }
    }

    public class EditUserViewModel : UserRoleInfoViewModel
    {
        [Required]
        public string UserId { get; set; }

    }




    public class ResetPasswordViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "注册邮箱")]
        public string Email { get; set; }


        public string TrueName { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "{0} 至少包含{2}位字符", MinimumLength = 6)]
        //[DataType(DataType.Password)]
        [Display(Name = "新密码")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "确认密码")]
        [Compare("Password", ErrorMessage = "两次密码输入不匹配")]
        public string ConfirmPassword { get; set; }

        public string Code { get; set; }
    }

    public class ForgotPasswordViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "注册邮箱")]
        public string Email { get; set; }
    }

    [Serializable]
    public class OWVMIdentityModel
    {
        public string UserId { get; set; }
        public string Email { get; set; }
        public IList<string> Roles { get; set; }
        public string UserName { get; set; }
        private string _trueName = null;

        public string Name
        {
            get { return _trueName; }
            set { _trueName = value; }
        }

        public bool IsAuthenticated { get; set; }

        public string AuthenticationType { get; set; }


        public string GetUserId()
        {
            return UserId;
        }

        public IList<string> GetUserRoles()
        {
            return Roles;
        }

        public string GetUserName()
        {
            return UserName;
        }

        public OWVMIdentityModel(string userId, string email, string userName, string trueName, IList<string> roles)
        {
            UserId = userId;
            Email = email;
            Roles = roles;
            UserName = userName;
            _trueName = trueName;
            IsAuthenticated = true;
        }

        public bool IsInRole(string name)
        {
            return Roles.Contains(name);
        }
    }

    [Serializable]
    public class OWVMUserModel
    {
        public OWVMIdentityModel Identity
        {
            get;
            set;
        }
        public bool IsInRole(string name)
        {

            return Identity.IsInRole(name);
        }

        public OWVMUserModel(OWVMIdentityModel identity)
        {
            Identity = identity;
        }

        public bool IsGA
        {
            get
            {
                return IsInRole("全局管理员");
            }
        }

        public bool IsCA
        {
            get
            {
                return IsInRole("管理员");
            }
        }


        public bool IsReporter
        {
            get
            {
                return IsInRole("普通用户");
            }
        }
    }
}
