﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Models
{
    public class AdvInfoMessage
    {
        public string deviceId { get; set; }
        public string advId { get; set; }
        public string contentUrl { get; set; }
        public DateTime endDate { get; set; }
    }

    public class SKUMessage
    {
        public string deviceId { get; set; }
        public string channelId { get; set; }
        public string skuName { get; set; }
        public string productImageUrl { get; set; }
        public decimal listPrice { get; set; }
        public string skuId { get; set; }
        public decimal discountPrice { get; set; }
    }
}