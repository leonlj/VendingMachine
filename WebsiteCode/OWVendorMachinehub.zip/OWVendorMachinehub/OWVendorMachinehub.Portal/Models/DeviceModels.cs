﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Models
{
    public class DeviceActivateModel
    {
        public string DeviceId { get; set; }
        public string DeviceKey { get; set; }
    }
}