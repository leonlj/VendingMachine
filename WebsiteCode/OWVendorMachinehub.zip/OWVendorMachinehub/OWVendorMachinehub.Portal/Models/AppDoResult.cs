﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Models
{
    public class AppDoResult : IdentityResult
    {
        public AppDoResult(params string[] errors)
            : base(errors)
        {

        }

        public AppDoResult(IEnumerable<string> errors)
            : base(errors)
        {
        }



        public AppDoResult(bool tag) : base(tag) { }


        static AppDoResult()
        {
            Success = new AppDoResult(true);
        }

        public static new AppDoResult Success { get; private set; }

        public Object State { get; set; }
    }
}