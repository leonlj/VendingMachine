﻿using OWVendorMachineHub.Portal.Db;
using OWVendorMachineHub.Portal.Db.Models;
using OWVendorMachineHub.Portal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OWVendorMachineHub.Portal.Controllers
{
    public class AddProductManageController : Controller
    {
        // GET: AddProduct
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult List(BootGridPagerModel model, string t = null, string k = "")
        {
            GridViewModel<AddProductsRecord> userData = new GridViewModel<AddProductsRecord> { current = model.current, rowCount = model.rowCount, total = 0, rows = null };

            using (ApplicationDbContext context = new ApplicationDbContext())
            {
                var q = context.AddProductRecords.Where(p => 1 == 1);
                if (t == "deviceId" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.deviceId == k);
                }
                else if (t == "skuId" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.skuId == k);
                }

                userData.total = q.Count();
                userData.rows = q.OrderByDescending(d => d.addTime).Skip(userData.rowCount * (userData.current - 1)).Take(userData.rowCount).ToList();
            }

            return Json(userData);
        }
    }
}