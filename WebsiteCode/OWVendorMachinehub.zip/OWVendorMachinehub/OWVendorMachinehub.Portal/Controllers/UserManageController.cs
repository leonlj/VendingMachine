﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using OWVendorMachineHub.Portal.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using OWVendorMachineHub.Portal.Utils;
using System.Text;
using System.Data.Entity;
using OWVendorMachineHub.Portal.Db.Models;

namespace OWVendorMachineHub.Portal.Controllers
{

    public class UserManageController : OWVendorMachineHubControllerBase
    {
        // GET: UserManage
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Users(BootGridPagerModel model)
        {
            GridViewModel<UserInfoListViewModel> userData = new GridViewModel<UserInfoListViewModel> { current = model.current, rowCount = model.rowCount, total = 0, rows = null };
            int skipCount = (model.current - 1) * model.rowCount;
            userData.rows = UserManager.Users.OrderByDescending(u => u.CreateTime).Skip(skipCount).Take(model.rowCount).ToArray().Select(u => u.ToUserInfoListViewModel()).ToList();
            return Json(userData);
        }

        [HttpPost]
        public async Task<ActionResult> Disable(string userId)
        {
            var result = await EnableOrDisableUser(userId, true);
            return Json(result);
        }

        [HttpPost]
        public async Task<ActionResult> Enable(string userId)
        {
            var result = await EnableOrDisableUser(userId, false);
            return Json(result);
        }


        private async Task<AjaxResult> EnableOrDisableUser(string userId, bool disabled)
        {
            AjaxResult result = new AjaxResult { Status = -1, Message = disabled ? "禁用用户失败！" : "启用用户失败！" };
            UserInfo userInfo = await UserManager.FindByIdAsync(userId);
            if (userInfo == null)
            {
                result.Message = "用户不存在！";
            }
            else
            {
                userInfo.IsDelete = disabled;
                userInfo.UpdateTime = DateTime.Now.ToOWVMUniversivalTime();
                userInfo.UpdateUser = User.Identity.GetUserId();
                var disableResult = await UserManager.UpdateAsync(userInfo);
                if (disableResult.Succeeded)
                {
                    result.Status = 1;
                    result.Message = disabled ? "禁用用户成功！" : "启用用户成功！";
                }
            }
            return result;
        }



    }
}