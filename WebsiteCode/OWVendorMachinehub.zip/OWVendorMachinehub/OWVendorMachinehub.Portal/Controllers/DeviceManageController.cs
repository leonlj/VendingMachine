﻿using OWVendorMachineHub.Portal.Db;
using OWVendorMachineHub.Portal.Db.Models;
using OWVendorMachineHub.Portal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;

namespace OWVendorMachineHub.Portal.Controllers
{
    public class DeviceManageController : OWVendorMachineHubControllerBase
    {
        // GET: Device
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Devices(BootGridPagerModel model, string t = null, string k = "")
        {
            GridViewModel<VMDeviceInfo> userData = new GridViewModel<VMDeviceInfo> { current = model.current, rowCount = model.rowCount, total = 0, rows = null };

            using (ApplicationDbContext context = new ApplicationDbContext())
            {
                var q = context.VMDeviceInfoes.Where(d => d.flag == "1");
                if (t == "id" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.deviceId == k);
                }
                else if (t == "adid" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.advId == k);
                }

                userData.total = q.Count();
                userData.rows = q.OrderByDescending(d => d.deviceId).Skip(userData.rowCount * (userData.current - 1)).Take(userData.rowCount).ToList();
            }

            return Json(userData);
        }

        [HttpGet]
        public ActionResult NewDevice()
        {
            return View();
        }

        [HttpPost]
        public ActionResult NewDevice(VMDeviceInfo model)
        {
            if (ModelState.IsValid)
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var device = context.VMDeviceInfoes.FirstOrDefault(d => d.deviceId == model.deviceId);
                    if (device != null)
                    {
                        AddErrors(new AppDoResult("设备ID已存在，请使用新ID！"));
                    }
                    else
                    {
                        if (VerifyDeviceData(model, context))
                        {
                            device = model;
                            device.healthFlag = string.IsNullOrEmpty(device.healthFlag) ? null : device.healthFlag;
                            context.VMDeviceInfoes.Add(device);
                            if (context.SaveChanges() > 0)
                            {
                                if (model.channelNo > 0)
                                {
                                    for (int i = 1; i <= model.channelNo; i++)
                                    {
                                        context.VMDeviceChannelInfoes.Add(new VMDeviceChannelInfo
                                        {
                                            deviceId = model.deviceId,
                                            channelId = string.Format("{0:d2}", i)
                                        });
                                    }

                                    if (context.SaveChanges() > 0)
                                    {
                                        return OWRedirectResult.Redirect("/DeviceManage/");
                                    }
                                    else
                                    {
                                        AddErrors(new AppDoResult("初始化货道信息失败！"));
                                    }
                                }


                                if (!string.IsNullOrEmpty(model.advId) && model.healthFlag != null)
                                {
                                    UpdateDeviceADInfoToCloud(model.deviceId, model.advId, context);
                                }

                            }
                            else
                            {
                                AddErrors(new AppDoResult("添加新设备失败，请重试！"));
                            }
                        }
                    }
                }
            }
            return View();
        }

        [HttpGet]
        public ActionResult EditDevice(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                ViewBag.ErrorMessage = "设备不存在！";
            }
            else
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var device = context.VMDeviceInfoes.FirstOrDefault(d => d.flag == "1" && d.deviceId == id);
                    if (device != null)
                    {
                        return View(device);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "设备不存在！";
                    }
                }
            }
            return View();
        }

        [HttpPost]
        public ActionResult EditDevice(VMDeviceInfo model)
        {
            if (ModelState.IsValid)
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var device = context.VMDeviceInfoes.FirstOrDefault(d => d.deviceId == model.deviceId);
                    if (device == null)
                    {
                        AddErrors(new AppDoResult("编辑设备失败，设备不存在！"));
                    }
                    else
                    {
                        if (VerifyDeviceData(model, context))
                        {

                            device.advId = model.advId;
                            device.contactId = model.contactId;
                            device.province = model.province;
                            device.city = model.city;
                            device.district = model.district;
                            device.deviceAddress = model.deviceAddress;
                            device.deviceType = model.deviceType;
                            device.healthFlag = string.IsNullOrEmpty(model.healthFlag) ? null : model.healthFlag;

                            if (context.SaveChanges() >= 0)
                            {
                                if (!string.IsNullOrEmpty(model.advId) && model.healthFlag != null)
                                {
                                    UpdateDeviceADInfoToCloud(model.deviceId, model.advId, context);
                                }

                                return OWRedirectResult.Redirect("/DeviceManage/");
                            }
                            else
                            {
                                AddErrors(new AppDoResult("保存设备信息失败，请重试！"));
                            }
                        }
                    }
                }
            }
            return View(model);
        }


        private bool VerifyDeviceData(VMDeviceInfo model, ApplicationDbContext context)
        {
            if (!string.IsNullOrEmpty(model.advId))
            {
                var ad = context.AdvertisementInfoes.FirstOrDefault(a => a.flag == "1" && a.advId == model.advId);
                if (ad == null)
                {
                    AddErrors(new AppDoResult("广告 id 不存在"));
                    return false;
                }
            }
            if (!string.IsNullOrEmpty(model.contactId))
            {
                var contact = context.ContactInfoes.FirstOrDefault(c => c.flag == "1" && c.contactId == model.contactId);
                if (contact == null)
                {
                    AddErrors(new AppDoResult("联系人id 不存在"));
                    return false;
                }
            }

            return true;
        }


        [HttpPost]
        public async Task<ActionResult> Delete(string id)
        {

            AjaxResult result = new AjaxResult { Status = -1, Message = "删除设备失败！" };

            if (!string.IsNullOrEmpty(id))
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var device = context.VMDeviceInfoes.FirstOrDefault(d => d.flag == "1" && d.deviceId == id);
                    if (device != null)
                    {
                        device.flag = "0";
                        if (context.SaveChanges() > 0)
                        {
                            result.Status = 1;
                            result.Message = "ok";
                        }

                        if (device.healthFlag != null)
                        {
                            try
                            {
                                await RegistryManager.RemoveDeviceAsync(id);
                            }
                            catch (Exception)
                            {
                                //throw;
                            }

                        }
                    }
                    else
                    {
                        result.Message = " 删除失败，设备不存在！";
                    }
                }
            }
            return Json(result);
        }





    }





}