﻿using OWVendorMachineHub.Portal.Db;
using OWVendorMachineHub.Portal.Db.Models;
using OWVendorMachineHub.Portal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OWVendorMachineHub.Portal.Controllers
{
    public class DeviceStatusManageController : OWVendorMachineHubControllerBase
    {
        // GET: DeviceStatusMange
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult List(BootGridPagerModel model, string t = null, string k = "")
        {
            GridViewModel<VMStatusRecord> userData = new GridViewModel<VMStatusRecord> { current = model.current, rowCount = model.rowCount, total = 0, rows = null };

            using (ApplicationDbContext context = new ApplicationDbContext())
            {
                var q = context.VMStatusRecords.Where(p => 1 == 1);
                if (t == "deviceId" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.deviceId == k);
                }
                else if (t == "healthFlag" && !string.IsNullOrEmpty(k))
                {
                    k = k.Replace("健康", "HEALTH").Replace("下降", "DOWN").Replace("报警", "ALERT");
                    q = q.Where(d => d.healthFlag == k);
                }

                userData.total = q.Count();
                try
                {
                    userData.rows = q.OrderByDescending(d => d.addDate).Skip(userData.rowCount * (userData.current - 1)).Take(userData.rowCount).ToList();
                }
                catch (Exception)
                {

                    throw;
                }
              
            }

            return Json(userData);
        }
    }
}