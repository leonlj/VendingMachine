﻿using Microsoft.Azure.Devices;
using Microsoft.Azure.Devices.Common.Exceptions;
using OWVendorMachineHub.Portal.Db;
using OWVendorMachineHub.Portal.Db.Models;
using OWVendorMachineHub.Portal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;

namespace OWVendorMachineHub.Portal.Controllers
{
    public class DeviceController : OWVendorMachineHubControllerBase
    {
        // GET: Device
        public async Task<ActionResult> Activate(string deviceId)
        {
            var result = await AddDeviceAsync(deviceId);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        private async Task<AjaxResult<DeviceActivateModel>> AddDeviceAsync(string deviceId)
        {
            AjaxResult<DeviceActivateModel> result = new AjaxResult<DeviceActivateModel> { Status = -1, Message = "设备激活失败！" };

            using (ApplicationDbContext context = new ApplicationDbContext())
            {
                var vmdevice = context.VMDeviceInfoes.FirstOrDefault(d => d.deviceId == deviceId && d.flag == "1");
                if (vmdevice == null)
                {
                    result.Message = "设备不存在于系统中，请先将设备加入系统中后，重新激活设备！";
                    return result;
                }

                Device device = null;
                bool devicAlreadyEexsits = false;
                try
                {
                    device = await RegistryManager.AddDeviceAsync(new Device(deviceId));
                    devicAlreadyEexsits = false;
                }
                catch (DeviceAlreadyExistsException)
                {
                    devicAlreadyEexsits = true;
                }
                catch (Exception ex)
                {
                    return result;
                }

                if (devicAlreadyEexsits == true)
                {
                    device = await RegistryManager.GetDeviceAsync(deviceId);
                }

                if (device != null)
                {
                    vmdevice.healthFlag = HealthStatus.HEALTH.ToString();
                    context.SaveChanges();
                    result.Status = 1;
                    result.Message = "ok";
                    result.Data = new DeviceActivateModel { DeviceId = deviceId, DeviceKey = device.Authentication.SymmetricKey.PrimaryKey };


                    var channels = context.VMDeviceChannelInfoes.Include(c => c.ProductInfo).Where(c => c.deviceId == vmdevice.deviceId && c.skuId != null).ToArray();

                   

                    if (channels != null && channels.Length > 0)
                    {
                        foreach (var item in channels)
                        {
                            if (item.ProductInfo != null)
                            {
                                item.listPrice = item.ProductInfo.listPrice;
                                item.productImageUrl = item.ProductInfo.productImageUrl;
                                item.skuName = item.ProductInfo.productName;
                            }
                        }

                        UpdateChannelInfoToCloud(channels);
                    }

                    if (!string.IsNullOrEmpty(vmdevice.advId))
                    {
                        UpdateDeviceADInfoToCloud(vmdevice.deviceId, vmdevice.advId, context);
                    }

                }
            }
            return result;
        }

    }
}