﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity.Owin;
using OWVendorMachineHub.Portal.Utils;
using OWVendorMachineHub.Portal.Models;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Security.Principal;
using OWVendorMachineHub.Portal.Services;
using OWVendorMachineHub.Portal.Db.Models;
using Microsoft.Azure.Devices;
using System.IO;
using OWVendorMachineHub.Portal.Db;
using System.Text;

namespace OWVendorMachineHub.Portal.Controllers
{
    public class OWVendorMachineHubControllerBase : Controller
    {
        public new OWVMUserModel User
        {
            get
            {
                if (this.HttpContext != null)
                {
                    if (Session[AppConfig.SESSION_USERI_IDENTITY] != null)
                    {
                        return Session[AppConfig.SESSION_USERI_IDENTITY] as OWVMUserModel;
                    }

                }
                return null;
            }

            protected set
            {
                Session[AppConfig.SESSION_USERI_IDENTITY] = value;
            }
        }


        private UserInfoManager _userManager;


        public UserInfoManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<UserInfoManager>();
            }
            private set
            {
                _userManager = value;
            }
        }


        private static RegistryManager _registryManager;


        //Hub name: OWvm1.azure-devices.net
        //Rule name: iothubowner
        //Rule Key: AycyzDzXd+6zcOSFnhPqHG1BfxLX/X9nY2NzVYuAWyY=


        public RegistryManager RegistryManager
        {
            get
            {
                if (_registryManager == null)
                {
                    _registryManager = RegistryManager.CreateFromConnectionString(AppConfig.IotHubConfig.ToString());
                }
                return _registryManager;
            }
        }


        private static ServiceClient _serviceClient = null;
        public ServiceClient IotHubServiceClient
        {
            get
            {
                if (_serviceClient == null)
                {
                    _serviceClient = ServiceClient.CreateFromConnectionString(AppConfig.IotHubConfig.ToString());

                    Task.Run(() =>
                    {
                        ReceiveFeedbackAsync();
                    });
                }

                return _serviceClient;
            }
        }

        private async void ReceiveFeedbackAsync()
        {
            var feedbackReceiver = _serviceClient.GetFeedbackReceiver();

            _logger.Log(new OWVMLog("Receiving c2d feedback from service"));
            while (true)
            {
                try
                {
                    var feedbackBatch = await feedbackReceiver.ReceiveAsync();
                    if (feedbackBatch == null) continue;


                    _logger.Log(new OWVMLog("process feedbath start"));

                    foreach (var item in feedbackBatch.Records)
                    {
                        _logger.Log(new OWVMLog(string.Format("deviceId:{0}\tmsgId:{1}\tstatusCode:{2}\tdescription:{3}", item.DeviceId, item.OriginalMessageId, item.StatusCode, item.Description)));
                    }
                    _logger.Log(new OWVMLog("process feedbath completed"));

                    await feedbackReceiver.CompleteAsync(feedbackBatch);
                }
                catch (Exception exp)
                {
                    _logger.Log(new OWVMLog(exp.Message));
                }

            }
        }







        protected void UpdateChannelInfoToCloud(VMDeviceChannelInfo[] channelInfoes)
        {
            if (channelInfoes != null && channelInfoes.Length > 0)
            {
                SKUMessage[] msgs = channelInfoes.Select(channelInfo => new SKUMessage
                {
                    channelId = channelInfo.channelId,
                    deviceId = channelInfo.deviceId,
                    discountPrice = channelInfo.discountPrice,
                    listPrice = channelInfo.listPrice,
                    productImageUrl = channelInfo.productImageUrl,
                    skuName = channelInfo.skuName,
                    skuId = channelInfo.skuId
                }).ToArray();

                string msgContent = Newtonsoft.Json.JsonConvert.SerializeObject(msgs);

                Task.Run(() =>
                {
                    var client = ServiceClient.CreateFromConnectionString(AppConfig.IotHubConfig.ToString());
                    client.SendAsync(channelInfoes[0].deviceId, new Microsoft.Azure.Devices.Message(Encoding.ASCII.GetBytes(msgContent)) { Ack = DeliveryAcknowledgement.Full }).Wait();
                    Logger.Log(new Utils.OWVMLog("send completed."));
                });
                Logger.Log(new Utils.OWVMLog(msgContent));
            }
        }



        protected void UpdateDeviceADInfoToCloud(string deviceId, string adId, ApplicationDbContext context)
        {
            var adInfo = context.AdvertisementInfoes.FirstOrDefault(ad => ad.advId == adId && ad.flag == "1");
            if (adInfo != null)
            {
                AdvInfoMessage msg = new AdvInfoMessage { deviceId = deviceId, advId = adInfo.advId, contentUrl = adInfo.contentUrl, endDate = adInfo.endDate };

                AdvInfoMessage[] msgs = new AdvInfoMessage[] { msg };

                string msgContent = Newtonsoft.Json.JsonConvert.SerializeObject(msgs);

                Task.Run(() =>
                {
                    var client = ServiceClient.CreateFromConnectionString(AppConfig.IotHubConfig.ToString());
                    client.SendAsync(deviceId, new Microsoft.Azure.Devices.Message(Encoding.ASCII.GetBytes(msgContent)) { Ack = DeliveryAcknowledgement.Full }).Wait();
                    Logger.Log(new Utils.OWVMLog("send completed."));
                });
                Logger.Log(new Utils.OWVMLog(msgContent));
            }
        }





        private static Logger _logger = null;
        public Logger Logger
        {
            get
            {
                return _logger;
            }
        }


        private static void InitLogger()
        {
            string logPath = AppDomain.CurrentDomain.BaseDirectory + "Logs";
            if (!Directory.Exists(logPath))
            {
                Directory.CreateDirectory(logPath);
            }

            _logger = new Logger(logPath);
        }



        static OWVendorMachineHubControllerBase()
        {
            InitLogger();
        }




        protected void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }





        /// <summary>
        /// 获取所有管理员列表
        /// </summary>
        /// <param name="oppProviderId"></param>
        /// <returns></returns>
        protected async Task<string[]> GetAdminEmailsAsync()
        {
            List<string> adminEmails = new List<string>();
            var admins = (await UserManager.FindUsersByRoleName("管理员")).Select(u => u.Email).ToArray();
            var gas = (await UserManager.FindUsersByRoleName("全局管理员")).Select(u => u.Email).ToArray();

            adminEmails.AddRange(admins);
            foreach (var item in gas)
            {
                if (!adminEmails.Contains(item))
                    adminEmails.Add(item);
            }
            return adminEmails.ToArray();
        }

        /// <summary>
        /// 获取普通管理员列表
        /// </summary>
        /// <returns></returns>
        protected async Task<string[]> GetCAEmailsAsync()
        {
            var admins = (await UserManager.FindUsersByRoleName("管理员")).Select(u => u.Email).ToArray();
            return admins;
        }

        /// <summary>
        /// 获取全局管理员列表
        /// </summary>
        /// <param name="oppProviderId"></param>
        /// <returns></returns>
        protected async Task<string[]> GetGAEmailsAsync()
        {
            var gas = (await UserManager.FindUsersByRoleName("全局管理员")).Select(u => u.Email).ToArray();
            return gas;
        }




        /// <summary>
        /// 获取全局管理员列表
        /// </summary>
        /// <returns></returns>
        protected async Task<List<UserInfo>> GetGAList()
        {
            return await UserManager.FindUsersByRoleName("全局管理员");
        }


        /// <summary>
        /// 根据当前用户角色获取当前用户 home url
        /// </summary>
        /// <returns></returns>
        protected string GetUserHomeUrl()
        {
            if (User.IsCA || User.IsGA)
                return "/UserManage/";
            return "/Account/Edit";
        }

        protected void ClearUserLoginInfo()
        {
            Session.Remove(AppConfig.SESSION_USERI_IDENTITY);
            var cookie = Request.Cookies.Get(AppConfig.COOKIE_USER_SECURITY_STAMP);
            if (cookie != null)
            {
                cookie.Value = null;
                cookie.Expires = new DateTime(1970, 1, 1);
                Response.AppendCookie(cookie);
            }
        }


        protected string CurrentUserId
        {
            get
            {
                return User == null ? Guid.Empty.ToString() : User.Identity.UserId;
            }
        }

        protected DateTime CurrentTime
        {
            get
            {
                return DateTime.Now.ToOWVMUniversivalTime();
            }
        }

    }
}