﻿using OWVendorMachineHub.Portal.Db;
using OWVendorMachineHub.Portal.Db.Models;
using OWVendorMachineHub.Portal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OWVendorMachineHub.Portal.Controllers
{
    public class ADManageController : OWVendorMachineHubControllerBase
    {// GET: Product
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult List(BootGridPagerModel model, string t = null, string k = "")
        {
            GridViewModel<AdvertisementInfo> userData = new GridViewModel<AdvertisementInfo> { current = model.current, rowCount = model.rowCount, total = 0, rows = null };

            using (ApplicationDbContext context = new ApplicationDbContext())
            {
                var q = context.AdvertisementInfoes.Where(d => d.flag == "1");
                if (t == "id" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.advId == k);
                }
                else if (t == "url" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.contentUrl.Contains(k));
                }

                userData.total = q.Count();
                userData.rows = q.OrderByDescending(d => d.advId).Skip(userData.rowCount * (userData.current - 1)).Take(userData.rowCount).ToList();
            }

            return Json(userData);
        }

        [HttpGet]
        public ActionResult New()
        {
            return View();
        }

        [HttpPost]
        public ActionResult New(AdvertisementInfo model)
        {
            if (ModelState.IsValid)
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var adv = model;
                    adv.advId = DateTime.UtcNow.ToString("yyyyMMddHHmmss");
                    context.AdvertisementInfoes.Add(adv);
                    if (context.SaveChanges() > 0)
                    {
                        return OWRedirectResult.Redirect("/ADManage/");
                    }
                    else
                    {
                        AddErrors(new AppDoResult("添加广告失败，请重试！"));
                    }
                }
            }
            return View();
        }


        [HttpGet]
        public ActionResult Edit(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                ViewBag.ErrorMessage = "广告不存在！";
            }
            else
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var adv = context.AdvertisementInfoes.FirstOrDefault(d => d.flag == "1" && d.advId == id);
                    if (adv != null)
                    {
                        return View(adv);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "广告不存在！";
                    }
                }
            }
            return View();
        }

        [HttpPost]
        public ActionResult Edit(AdvertisementInfo model)
        {
            if (ModelState.IsValid)
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var adv = context.AdvertisementInfoes.FirstOrDefault(d => d.advId == model.advId);
                    if (adv == null)
                    {
                        AddErrors(new AppDoResult("编辑广告失败，广告不存在！"));
                    }
                    else
                    {
                        adv.advType = model.advType;
                        adv.contentUrl = model.contentUrl;
                        adv.startDate = model.startDate;
                        adv.endDate = model.endDate;

                        if (context.SaveChanges() >= 0)
                        {
                            var devices = context.VMDeviceInfoes.Where(d => d.flag == "1" && d.advId == adv.advId).ToArray();
                            if (devices != null && devices.Length > 0)
                            {
                                foreach (var item in devices)
                                {
                                    UpdateDeviceADInfoToCloud(item.deviceId, adv.advId, context);
                                }
                            }

                            return OWRedirectResult.Redirect("/ADManage/");
                        }
                        else
                        {
                            AddErrors(new AppDoResult("保存广告信息失败，请重试！"));
                        }
                    }
                }
            }
            return View(model);
        }



        [HttpPost]
        public ActionResult Delete(string id)
        {

            AjaxResult result = new AjaxResult { Status = -1, Message = "删除广告失败！" };

            if (!string.IsNullOrEmpty(id))
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var device = context.AdvertisementInfoes.FirstOrDefault(d => d.flag == "1" && d.advId == id);
                    if (device != null)
                    {
                        device.flag = "0";
                        if (context.SaveChanges() > 0)
                        {
                            result.Status = 1;
                            result.Message = "ok";
                        }
                    }
                    else
                    {
                        result.Message = " 删除失败，广告不存在！";
                    }
                }
            }
            return Json(result);
        }
    }
}