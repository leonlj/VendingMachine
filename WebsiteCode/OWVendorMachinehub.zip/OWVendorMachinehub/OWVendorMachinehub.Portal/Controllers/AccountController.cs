﻿using System;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using OWVendorMachineHub.Portal.Models;
using OWVendorMachineHub.Portal.Utils;
using Microsoft.AspNet.Identity.EntityFramework;
using System.Collections.Generic;
using System.Text;
using OWVendorMachineHub.Portal.Db.Models;
using OWVendorMachineHub.Portal.Services;

namespace OWVendorMachineHub.Portal.Controllers
{

    public class AccountController : OWVendorMachineHubControllerBase
    {


        public AccountController()
        {

        }


        //
        // GET: /Account/Login
        [AllowAnonymous]
        [HttpGet]
        public ActionResult Login(string returnUrl, int wcBind = 0)
        {
            if (wcBind == 1)
            {
                ClearUserLoginInfo();
            }
            return View();
        }

        private UserSignInManager _signInManager;

        public UserSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? HttpContext.GetOwinContext().Get<UserSignInManager>();
            }
            private set { _signInManager = value; }
        }




        private RoleInfoManager _roleInfoManager;
        public RoleInfoManager RoleInfoManager
        {
            get
            {
                return _roleInfoManager ?? HttpContext.GetOwinContext().Get<RoleInfoManager>();
            }
            set
            {
                _roleInfoManager = value;
            }
        }






        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        ////[ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(LoginViewModel model, string returnUrl)
        {
            ClearUserLoginInfo();

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // This doesn't count login failures towards account lockout
            // To enable password failures to trigger account lockout, change to shouldLockout: true
            var result = await SignInManager.PasswordSignInAsync(model.Email, model.NewPassword, model.RememberMe, shouldLockout: false);


            switch (result)
            {
                case SignInStatus.Success:

                    UserInfo userInfo = await UserManager.FindByNameAsync(model.Email);

                    var roles = userInfo.GetUserRoleNames();

                    if (!userInfo.IsDelete || roles.Contains("全局管理员"))
                    {
                        User = new OWVMUserModel(new OWVMIdentityModel(userInfo.Id, userInfo.Email, userInfo.UserName, userInfo.TrueName, roles));

                        if (model.RememberMe)
                        {
                            string stamp = string.Format("{0:yyyy-MM-dd HH:mm:ss}+{1}", DateTime.Now.ToOWVMUniversivalTime(), userInfo.SecurityStamp);
                            byte[] buffer = Encoding.UTF8.GetBytes(stamp);
                            var stampCookie = new HttpCookie(AppConfig.COOKIE_USER_SECURITY_STAMP) { Value = Convert.ToBase64String(buffer), Expires = DateTime.Now.AddMonths(2) };
                            Response.SetCookie(stampCookie);
                        }

                        if (!string.IsNullOrEmpty(returnUrl))
                        {
                            return OWRedirectResult.Redirect(returnUrl, false);
                        }
                        else
                        {
                            return OWRedirectResult.Redirect(GetUserHomeUrl(), false);
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "账户被禁止登陆");
                        return View(model);
                    }
                case SignInStatus.LockedOut:
                    return View("Lockout");
                case SignInStatus.RequiresVerification:
                    return RedirectToAction("SendCode", new { ReturnUrl = returnUrl, RememberMe = model.RememberMe });
                case SignInStatus.Failure:
                default:
                    ModelState.AddModelError("", "登陆失败");
                    return View(model);
            }
        }


        //
        // GET: /Account/Register
        [AllowAnonymous]
        public ActionResult Register()
        {
            ClearUserLoginInfo();
            return View();
        }

        //
        // POST: /Account/Register
        [HttpPost]
        [AllowAnonymous]
        ////[ValidateAntiForgeryToken]
        public async Task<ActionResult> Register(RegisterViewModel model)
        {
            ClearUserLoginInfo();
            if (ModelState.IsValid)
            {
                var addUserModel = model.ToAddUserViewModel();
                addUserModel.Roles = AppConfig.UserRoles.FirstOrDefault(r => r.Value == "报备人员").Key;

                var result = await AddNewUser(addUserModel);
                if (result.Succeeded)
                {
                    var user = await UserManager.FindByEmailAsync(addUserModel.Email);
                    if (user != null)
                    {
                        Session[AppConfig.SESSION_USERI_IDENTITY] = new OWVMUserModel(new OWVMIdentityModel(user.Id, user.Email, user.UserName, user.TrueName, user.GetUserRoleNames()));
                    }

                    return OWRedirectResult.Redirect(GetUserHomeUrl(), false);
                }
                else
                {
                    AddErrors(result);
                }
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }


        [HttpGet]
        public ActionResult AddUser()
        {
            ViewBag.AllRoles = GetRolesUserCanAuthorized();
            return View();
        }

        [HttpPost]
        ////[ValidateAntiForgeryToken]
        public async Task<ActionResult> AddUser(AddUserViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = await AddNewUser(model);
                if (result.Succeeded)
                {
                    return OWRedirectResult.Redirect(Url.Content("~/UserManage/"));
                }
                else
                {
                    AddErrors(result);
                }
            }
            ViewBag.AllRoles = GetRolesUserCanAuthorized();
            return View();
        }

        /// <summary>
        /// for Admin
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<ActionResult> EditUser(string userId)
        {
            ViewBag.AllRoles = GetRolesUserCanAuthorized();
            if (!string.IsNullOrEmpty(userId))
            {
                UserInfo userinfo = await UserManager.FindByIdAsync(userId);
                if (userinfo != null)
                {
                    if (userinfo.GetMaxAuthorizationLevel() > User.Identity.GetMaxAuthorizationLevel())
                    {
                        ViewBag.ErrorMessage = "您需要更高权限级别来编辑此用户信息";
                        return View();
                    }

                    return View(userinfo.ToEditUserViewModel());
                }

            }
            ViewBag.ErrorMessage = "指定用户不存在！";
            return View();
        }

        /// <summary>
        /// for admin
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        ////[ValidateAntiForgeryToken]
        public async Task<ActionResult> EditUser(EditUserViewModel model)
        {
            var allRoles = GetRolesUserCanAuthorized();
            ViewBag.AllRoles = allRoles;

            if (ModelState.IsValid)
            {
                string[] newRoles = model.Roles.Trim(',').Split(',');
                var invalidRoles = newRoles.Where(nr => !allRoles.ContainsKey(nr)).ToList();
                if (invalidRoles != null && invalidRoles.Count > 0)
                {
                    ViewBag.ErrorMessage = "您需要更高权限级别来编辑此用户权限信息";
                    return View();
                }

                var editResult = await EditUserInfo(model);
                if (editResult.Succeeded)
                {
                    return OWRedirectResult.Redirect(Url.Content("~/UserManage/"));
                }
                else
                {
                    AddErrors(editResult);
                }
            }
            return View(model);
        }




        /// <summary>
        /// 获取当前用户能授权的角色，当前用户只能管理比自己权限级别低的用户，且只能授权比自己级别低的权限给用户
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, string> GetRolesUserCanAuthorized()
        {

            var maxLevel = User.Identity.GetMaxAuthorizationLevel();
            Dictionary<string, string> rolesDictionary = new Dictionary<string, string>();
            var roleIds = AppConfig.RoleLevels.Where(rl => rl.Value <= maxLevel).Select(rl => rl.Key).ToArray();
            string roleName = "";
            foreach (var item in roleIds)
            {
                roleName = AppConfig.UserRoles[item];
                if (roleName != "全局管理员")
                    rolesDictionary.Add(item, roleName);
            }
            return rolesDictionary;
        }

        [HttpGet]
        public async Task<ActionResult> Edit()
        {
            string userId = User.Identity.GetUserId();

            UserInfo userinfo = await UserManager.FindByIdAsync(userId);

            if (userinfo != null)
            {
                return View(userinfo.ToEditUserViewModel());
            }
            return Content("指定用户不存在!");
        }

        [HttpPost]
        public async Task<ActionResult> Edit(EditUserViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = await EditUserInfo(model, true);
                if (result.Succeeded)
                {

                    return OWRedirectResult.Redirect(GetUserHomeUrl());
                }
                else
                {
                    AddErrors(result);
                }
            }
            return View(model);
        }

        /// <summary>
        /// 添加用户：验证用户基本信息 -> 添加基本信息 -> 添加用户角色信息 -> 邮件提醒
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private async Task<IdentityResult> AddNewUser(AddUserViewModel model)
        {
            var addResult = await VerifyUserInfo(model);
            if (!addResult.Succeeded)
            {
                return addResult;
            }

            var userRoles = GetUserRoles(model);

            var newUserInfo = model.ToUserInfo();
            string newPassword = null;
            if (string.IsNullOrEmpty(model.Password))
            {
                newPassword = PasswordGenerator.GenerateNewPassword();
            }


            newUserInfo.Roles.Clear();

            foreach (var item in userRoles)
            {
                newUserInfo.Roles.Add(new UserRole { RoleId = item, UserId = newUserInfo.Id });
            }

            addResult = await UserManager.CreateAsync(newUserInfo, model.Password ?? newPassword);
            if (addResult.Succeeded)
            {
                return IdentityResult.Success;
            }
            return addResult;
        }

        /// <summary>
        /// 根据提交信息获取用户角色信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private string[] GetUserRoles(UserRoleInfoViewModel model)
        {
            if (!string.IsNullOrEmpty(model.Roles))
            {
                return model.Roles.Trim(',').Split(',');
            }
            return new string[0];
        }

        private Guid ToGuidArray(string providers)
        {
            Guid id = Guid.Parse(providers);
            return id;
        }


        /// <summary>
        /// 验证用户信息 -> 保存用户基本信息 -> 保存用户角色信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private async Task<IdentityResult> EditUserInfo(EditUserViewModel model, bool self = false)
        {
            var verifyResult = await VerifyUserInfo(model, model.UserId);
            if (!verifyResult.Succeeded)
                return verifyResult;

            string[] userRoles = GetUserRoles(model);
            UserInfo userInfo = await UserManager.FindByIdAsync(model.UserId);
            if (userInfo == null)
                return IdentityResult.Failed("指定用户不存在");
            userInfo.TrueName = model.Name;
            userInfo.PhoneNumber = model.Telphone;
            userInfo.UserName = model.Name;
            userInfo.Email = model.Email;
            userInfo.WeChatId = model.WeChatId;
            userInfo.UpdateTime = DateTime.Now.ToOWVMUniversivalTime();
            userInfo.UpdateUser = User.Identity.GetUserId();

            //管理员编辑其他用户信息
            if (!self)
            {
                userInfo.Roles.Clear();
                foreach (var item in userRoles)
                {
                    userInfo.Roles.Add(new UserRole { RoleId = item, UserId = userInfo.Id });
                }
            }

            var result = await UserManager.UpdateAsync(userInfo);

            return result;
        }

        /// <summary>
        /// 验证用户信息合法性：1. 手机号码合法性； 2.邮箱合法性。
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private async Task<IdentityResult> VerifyUserInfo(UserInfoViewModelBase model, string userId = null)
        {
            if (model == null)
                return IdentityResult.Failed("输入有误！");

            UserInfo userInfo = await UserManager.FindByPhoneAsync(model.Telphone);
            if (userInfo != null && userInfo.Id != userId)
            {
                return IdentityResult.Failed("添加失败，手机号码已经被登记，请更换手机号后重试！");
            }
            else
            {
                userInfo = await UserManager.FindByEmailAsync(model.Email);
                if (userInfo != null && userInfo.Id != userId)
                {
                    return IdentityResult.Failed("添加失败，邮箱已经被登记，请更换邮箱后重试！");
                }
            }
            return IdentityResult.Success;
        }


        //
        // GET: /Account/ConfirmEmail
        [AllowAnonymous]
        public async Task<ActionResult> ConfirmEmail(string userId, string code)
        {
            if (userId == null || code == null)
            {
                return View("Error");
            }
            var result = await UserManager.ConfirmEmailAsync(userId, code);
            return View(result.Succeeded ? "ConfirmEmail" : "Error");
        }

        //
        // GET: /Account/ForgotPassword
        [AllowAnonymous]
        public ActionResult ForgotPassword()
        {
            return View();
        }

        //
        // POST: /Account/ForgotPassword
        [HttpPost]
        [AllowAnonymous]
        ////[ValidateAntiForgeryToken]
        public async Task<ActionResult> ForgotPassword(ForgotPasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await UserManager.FindByEmailAsync(model.Email);
                if (user == null)
                {
                    // Don't reveal that the user does not exist or is not confirmed
                    return View("ForgotPasswordConfirmation");
                }
                else
                {
                    user.Signature = (await UserManager.GeneratePasswordResetTokenAsync(user.Id)).Replace("+", "");
                    var result = await UserManager.UpdateAsync(user);
                    if (result.Succeeded)
                    {
                        return View("ForgotPasswordConfirmation");
                    }
                }
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // GET: /Account/ForgotPasswordConfirmation
        [AllowAnonymous]
        public ActionResult ForgotPasswordConfirmation()
        {

            return View();
        }

        //
        // GET: /Account/ResetPassword
        [AllowAnonymous]
        public ActionResult ResetPassword(string code)
        {
            return code == null ? View("Error") : View();
        }

        //
        // POST: /Account/ResetPassword
        [HttpPost]
        [AllowAnonymous]
        ////[ValidateAntiForgeryToken]
        public async Task<ActionResult> ResetPassword(ResetPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }



            var user = await UserManager.FindByEmailAsync(model.Email);
            if (user == null || user.Signature != model.Code)
            {
                // Don't reveal that the user does not exist
                return RedirectToAction("ResetPasswordConfirmation", "Account");
            }

            user.PasswordHash = UserManager.PasswordHasher.HashPassword(model.Password);
            user.Signature = "";
            user.UpdateTime = DateTime.Now.ToOWVMUniversivalTime();
            user.UpdateUser = user.Id;
            var result = await UserManager.UpdateAsync(user);

            if (result.Succeeded)
            {
                return RedirectToAction("ResetPasswordConfirmation", "Account");
            }
            AddErrors(result);
            return View();
        }

        //
        // GET: /Account/ResetPasswordConfirmation
        [AllowAnonymous]
        public ActionResult ResetPasswordConfirmation()
        {
            return View();
        }




        //
        // POST: /Account/LogOff
        [HttpPost]
        ////[ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            AuthenticationManager.SignOut();

            ClearUserLoginInfo();
            //Session.Clear();

            return OWRedirectResult.Redirect("~/");
        }



        [AllowAnonymous]
        public ActionResult AccessDenied()
        {
            return View();
        }


        public async Task<ActionResult> Card(string userId)
        {
            var user = await UserManager.FindByIdAsync(userId);
            if (user != null)
            {
                var userModel = user.ToUserInfoListViewModel();
                return View(userModel);
            }
            else
            {
                return Content("用户不存在！");
            }
        }





        #region 暂未使用


        //
        // GET: /Account/VerifyCode
        [AllowAnonymous]
        public async Task<ActionResult> VerifyCode(string provider, string returnUrl, bool rememberMe)
        {
            // Require that the user has already logged in via username/password or external login
            if (!await SignInManager.HasBeenVerifiedAsync())
            {
                return View("Error");
            }
            var user = await UserManager.FindByIdAsync(await SignInManager.GetVerifiedUserIdAsync());
            if (user != null)
            {
                var code = await UserManager.GenerateTwoFactorTokenAsync(user.Id, provider);
            }
            return View(new VerifyCodeViewModel { Provider = provider, ReturnUrl = returnUrl, RememberMe = rememberMe });
        }

        //
        // POST: /Account/VerifyCode
        [HttpPost]
        [AllowAnonymous]
        //[ValidateAntiForgeryToken]
        public async Task<ActionResult> VerifyCode(VerifyCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // The following code protects for brute force attacks against the two factor codes. 
            // If a user enters incorrect codes for a specified amount of time then the user account 
            // will be locked out for a specified amount of time. 
            // You can configure the account lockout settings in IdentityConfig
            var result = await SignInManager.TwoFactorSignInAsync(model.Provider, model.Code, isPersistent: model.RememberMe, rememberBrowser: model.RememberBrowser);
            switch (result)
            {
                case SignInStatus.Success:
                    return RedirectToLocal(model.ReturnUrl);
                case SignInStatus.LockedOut:
                    return View("Lockout");
                case SignInStatus.Failure:
                default:
                    ModelState.AddModelError("", "Invalid code.");
                    return View(model);
            }
        }


        //
        // POST: /Account/ExternalLogin
        [HttpPost]
        [AllowAnonymous]
        //[ValidateAntiForgeryToken]
        public ActionResult ExternalLogin(string provider, string returnUrl)
        {
            // Request a redirect to the external login provider
            return new ChallengeResult(provider, Url.Action("ExternalLoginCallback", "Account", new { ReturnUrl = returnUrl }));
        }

        //
        // GET: /Account/SendCode
        [AllowAnonymous]
        public async Task<ActionResult> SendCode(string returnUrl, bool rememberMe)
        {
            var userId = await SignInManager.GetVerifiedUserIdAsync();
            if (userId == null)
            {
                return View("Error");
            }
            var userFactors = await UserManager.GetValidTwoFactorProvidersAsync(userId);
            var factorOptions = userFactors.Select(purpose => new SelectListItem { Text = purpose, Value = purpose }).ToList();
            return View(new SendCodeViewModel { Providers = factorOptions, ReturnUrl = returnUrl, RememberMe = rememberMe });
        }

        //
        // POST: /Account/SendCode
        [HttpPost]
        [AllowAnonymous]
        //[ValidateAntiForgeryToken]
        public async Task<ActionResult> SendCode(SendCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            // Generate the token and send it
            if (!await SignInManager.SendTwoFactorCodeAsync(model.SelectedProvider))
            {
                return View("Error");
            }
            return RedirectToAction("VerifyCode", new { Provider = model.SelectedProvider, ReturnUrl = model.ReturnUrl, RememberMe = model.RememberMe });
        }

        //
        // GET: /Account/ExternalLoginCallback
        [AllowAnonymous]
        public async Task<ActionResult> ExternalLoginCallback(string returnUrl)
        {
            var loginInfo = await AuthenticationManager.GetExternalLoginInfoAsync();
            if (loginInfo == null)
            {
                return RedirectToAction("Login");
            }

            // Sign in the user with this external login provider if the user already has a login
            var result = await SignInManager.ExternalSignInAsync(loginInfo, isPersistent: false);
            switch (result)
            {
                case SignInStatus.Success:
                    return RedirectToLocal(returnUrl);
                case SignInStatus.LockedOut:
                    return View("Lockout");
                case SignInStatus.RequiresVerification:
                    return RedirectToAction("SendCode", new { ReturnUrl = returnUrl, RememberMe = false });
                case SignInStatus.Failure:
                default:
                    // If the user does not have an account, then prompt the user to create an account
                    ViewBag.ReturnUrl = returnUrl;
                    ViewBag.LoginProvider = loginInfo.Login.LoginProvider;
                    return View("ExternalLoginConfirmation", new ExternalLoginConfirmationViewModel { Email = loginInfo.Email });
            }
        }

        //
        // POST: /Account/ExternalLoginConfirmation
        [HttpPost]
        [AllowAnonymous]
        //[ValidateAntiForgeryToken]
        public async Task<ActionResult> ExternalLoginConfirmation(ExternalLoginConfirmationViewModel model, string returnUrl)
        {
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "Manage");
            }

            if (ModelState.IsValid)
            {
                // Get the information about the user from the external login provider
                var info = await AuthenticationManager.GetExternalLoginInfoAsync();
                if (info == null)
                {
                    return View("ExternalLoginFailure");
                }
                var user = new UserInfo { UserName = model.Email, Email = model.Email };
                var result = await UserManager.CreateAsync(user);
                if (result.Succeeded)
                {
                    result = await UserManager.AddLoginAsync(user.Id, info.Login);
                    if (result.Succeeded)
                    {
                        await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
                        return RedirectToLocal(returnUrl);
                    }
                }
                AddErrors(result);
            }

            ViewBag.ReturnUrl = returnUrl;
            return View(model);
        }



        //
        // GET: /Account/ExternalLoginFailure
        [AllowAnonymous]
        public ActionResult ExternalLoginFailure()
        {
            return View();
        }

        #region Helpers
        // Used for XSRF protection when adding external logins
        private const string XsrfKey = "XsrfId";

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }



        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return OWRedirectResult.Redirect(returnUrl, false);
            }
            return OWRedirectResult.Redirect("/", false);
        }

        internal class ChallengeResult : HttpUnauthorizedResult
        {
            public ChallengeResult(string provider, string redirectUri)
                : this(provider, redirectUri, null)
            {
            }

            public ChallengeResult(string provider, string redirectUri, string userId)
            {
                LoginProvider = provider;
                RedirectUri = redirectUri;
                UserId = userId;
            }

            public string LoginProvider { get; set; }
            public string RedirectUri { get; set; }
            public string UserId { get; set; }

            public override void ExecuteResult(ControllerContext context)
            {
                var properties = new AuthenticationProperties { RedirectUri = RedirectUri };
                if (UserId != null)
                {
                    properties.Dictionary[XsrfKey] = UserId;
                }
                context.HttpContext.GetOwinContext().Authentication.Challenge(properties, LoginProvider);
            }
        }

        #endregion

        #endregion
    }
}