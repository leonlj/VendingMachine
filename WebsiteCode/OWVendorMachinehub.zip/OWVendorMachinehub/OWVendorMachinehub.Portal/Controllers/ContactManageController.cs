﻿using OWVendorMachineHub.Portal.Db;
using OWVendorMachineHub.Portal.Db.Models;
using OWVendorMachineHub.Portal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OWVendorMachineHub.Portal.Controllers
{
    public class ContactManageController : OWVendorMachineHubControllerBase
    {
        // GET: Product
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult List(BootGridPagerModel model, string t = null, string k = "")
        {
            GridViewModel<ContactInfo> userData = new GridViewModel<ContactInfo> { current = model.current, rowCount = model.rowCount, total = 0, rows = null };

            using (ApplicationDbContext context = new ApplicationDbContext())
            {
                var q = context.ContactInfoes.Where(d => d.flag == "1");
                if (t == "id" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.contactId == k);
                }
                else if (t == "name" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.contactName.Contains(k));
                }
                else if (t == "phone" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.contactPhone.Contains(k));
                }
                else if (t == "company" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.company.Contains(k));
                }
                else if (t == "email" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.contactEmail.Contains(k));
                }

                userData.total = q.Count();
                userData.rows = q.OrderByDescending(d => d.contactId).Skip(userData.rowCount * (userData.current - 1)).Take(userData.rowCount).ToList();
            }

            return Json(userData);
        }

        [HttpGet]
        public ActionResult New()
        {
            return View();
        }

        [HttpPost]
        public ActionResult New(ContactInfo model)
        {
            if (ModelState.IsValid)
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var contact = model;
                    contact.contactId = DateTime.UtcNow.ToString("yyyyMMddHHmmss");
                    context.ContactInfoes.Add(contact);
                    if (context.SaveChanges() > 0)
                    {
                        return OWRedirectResult.Redirect("/ContactManage/");
                    }
                    else
                    {
                        AddErrors(new AppDoResult("添加联系人失败，请重试！"));
                    }
                }
            }
            return View();
        }


        [HttpGet]
        public ActionResult Edit(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                ViewBag.ErrorMessage = "联系人不存在！";
            }
            else
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var contact = context.ContactInfoes.FirstOrDefault(d => d.flag == "1" && d.contactId == id);
                    if (contact != null)
                    {
                        return View(contact);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "联系人不存在！";
                    }
                }
            }
            return View();
        }

        [HttpPost]
        public ActionResult Edit(ContactInfo model)
        {
            if (ModelState.IsValid)
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var contact = context.ContactInfoes.FirstOrDefault(d => d.contactId == model.contactId);
                    if (contact == null)
                    {
                        AddErrors(new AppDoResult("编辑联系人失败，联系人不存在！"));
                    }
                    else
                    {
                        contact.contactName = model.contactName;
                        contact.contactEmail = model.contactEmail;
                        contact.contactPhone = model.contactPhone;
                        contact.company = model.company;
                        contact.others = model.others;

                        if (context.SaveChanges() >= 0)
                        {
                            return OWRedirectResult.Redirect("/ContactManage/");
                        }
                        else
                        {
                            AddErrors(new AppDoResult("保存联系人信息失败，请重试！"));
                        }
                    }
                }
            }
            return View(model);
        }



        [HttpPost]
        public ActionResult Delete(string id)
        {

            AjaxResult result = new AjaxResult { Status = -1, Message = "删除联系人失败！" };

            if (!string.IsNullOrEmpty(id))
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var device = context.ContactInfoes.FirstOrDefault(d => d.flag == "1" && d.contactId == id);
                    if (device != null)
                    {
                        device.flag = "0";
                        if (context.SaveChanges() > 0)
                        {
                            result.Status = 1;
                            result.Message = "ok";
                        }
                    }
                    else
                    {
                        result.Message = " 删除失败，联系人不存在！";
                    }
                }
            }
            return Json(result);
        }
    }
}