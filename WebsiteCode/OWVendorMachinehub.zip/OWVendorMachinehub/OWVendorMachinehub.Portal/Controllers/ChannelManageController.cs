﻿using OWVendorMachineHub.Portal.Db;
using OWVendorMachineHub.Portal.Db.Models;
using OWVendorMachineHub.Portal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Text;

namespace OWVendorMachineHub.Portal.Controllers
{
    public class ChannelManageController : OWVendorMachineHubControllerBase
    {
        // GET: ChannelManage
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Channels(BootGridPagerModel model, string t = null, string k = "")
        {
            GridViewModel<VMDeviceChannelInfo> userData = new GridViewModel<VMDeviceChannelInfo> { current = model.current, rowCount = model.rowCount, total = 0, rows = null };

            using (ApplicationDbContext context = new ApplicationDbContext())
            {
                var q = context.VMDeviceChannelInfoes.Include(c => c.DeviceInfo).Include(c => c.ProductInfo).Where(c => c.DeviceInfo.flag == "1");
                if (t == "id" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(c => c.DeviceInfo.deviceId == k);
                }
                else if (t == "adid" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(c => c.DeviceInfo.advId == k);
                }

                userData.total = q.Count();
                userData.rows = q.OrderBy(c => c.channelId).OrderByDescending(c => c.DeviceInfo.deviceId).Skip(userData.rowCount * (userData.current - 1)).Take(userData.rowCount)
                                .ToList()
                                .Select(c => new VMDeviceChannelInfo
                                {
                                    deviceId = c.deviceId,
                                    channelId = c.channelId,
                                    skuId = c.skuId,
                                    skuName = c.ProductInfo == null ? null : c.ProductInfo.productName,
                                    productImageUrl = c.ProductInfo == null ? null : c.ProductInfo.productImageUrl,
                                    listPrice = c.ProductInfo == null ? 0 : c.ProductInfo.listPrice,
                                    discountPrice = c.discountPrice
                                }).ToList();
            }

            return Json(userData);
        }

        [HttpGet]
        public ActionResult EditChannel(string id, string deviceId)
        {
            if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(deviceId))
            {
                ViewBag.ErrorMessage = "货道不存在！";
            }
            else
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var device = context.VMDeviceChannelInfoes
                        .Include(c => c.ProductInfo)
                        .FirstOrDefault(d => d.channelId == id && d.deviceId == deviceId);
                    if (device != null)
                    {
                        return View(device);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "货道不存在！";
                    }
                }
            }
            return View();
        }

        [HttpPost]
        public ActionResult EditChannel(VMDeviceChannelInfo model)
        {
            if (ModelState.IsValid)
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var channel = context.VMDeviceChannelInfoes.Include(c => c.DeviceInfo).FirstOrDefault(d => d.deviceId == model.deviceId && d.channelId == model.channelId && d.DeviceInfo.flag == "1");
                    if (channel == null)
                    {
                        AddErrors(new AppDoResult("编辑货道失败，货道不存在！"));
                    }
                    else
                    {
                        var prodcut = context.ProductInfoes.FirstOrDefault(p => p.flag == "1" && p.skuId == model.skuId);
                        if (prodcut == null)
                        {
                            AddErrors(new AppDoResult("保存货道信息失败，产品不存在！"));
                        }
                        else
                        {
                            channel.skuId = model.skuId;
                            channel.skuName = prodcut.productName;
                            channel.productImageUrl = prodcut.productImageUrl;
                            channel.listPrice = prodcut.listPrice;
                            channel.discountPrice = model.discountPrice;

                            if (context.SaveChanges() >= 0)
                            {
                                if (channel.skuId != null && channel.DeviceInfo.healthFlag != null)
                                {
                                    UpdateChannelInfoToCloud(new VMDeviceChannelInfo[] { channel });
                                }

                                return OWRedirectResult.Redirect("/ChannelManage/");
                            }
                            else
                            {
                                AddErrors(new AppDoResult("保存货道信息失败，请重试！"));
                            }
                        }
                    }
                }
            }
            return View(model);
        }

    }
}