﻿using OWVendorMachineHub.Portal.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace OWVendorMachineHub.Portal.Controllers
{
    public class UploadController : OWVendorMachineHubControllerBase
    {
        public ActionResult Prodcut(string fileContent, string fileName, string fileType)
        {
            AjaxResult<string> result = UploadOrderFiles(fileContent, fileName, fileType, UploadFileType.Products);
            return Json(result);
        }

        public ActionResult AD(string fileContent, string fileName, string fileType)
        {
            AjaxResult<string> result = UploadOrderFiles(fileContent, fileName, fileType, UploadFileType.ADs);
            return Json(result);
        }



        private AjaxResult<string> UploadOrderFiles(string fileContent, string fileName, string fileType, UploadFileType uploadFileType)
        {
            AjaxResult<string> result = new AjaxResult<string> { Status = -1, Message = "上传失败！" };
            string url = SaveFile(fileContent, fileName, uploadFileType);
            if (url != null)
            {
                result.Status = 1;
                result.Message = "ok";
                result.Data = url;
            }
            return result;
        }


        private string SaveFile(string fileContent, string fileName, UploadFileType uploadFileType)
        {
            byte[] buffer = Convert.FromBase64String(fileContent);
            string newFileName = string.Format("{0}{1}", Guid.NewGuid(), GetFileExtension(fileName));
            string fileDir = string.Format("{0}{1}/{2}", AppDomain.CurrentDomain.BaseDirectory, AppConfig.UploadConfig.Directory, uploadFileType.ToString());
            string fileFullName = string.Format("{0}/{1}", fileDir, newFileName);

            string url = null;

            if (!Directory.Exists(fileDir))
            {
                Directory.CreateDirectory(fileDir);
            }

            using (FileStream fs = new FileStream(fileFullName, FileMode.Create))
            {
                fs.Write(buffer, 0, buffer.Length);
                fs.Close();
                url = string.Format("{0}/{1}/{2}/{3}", AppConfig.UploadConfig.UploadUrlBase.Trim('/'), AppConfig.UploadConfig.Directory, uploadFileType.ToString(), newFileName);
            }
            return url;
        }

        private string GetFileExtension(string fileName)
        {
            if (fileName.IndexOf(".") > 0)
            {
                return fileName.Substring(fileName.LastIndexOf("."));
            }
            return "";
        }
    }
    public enum UploadFileType
    {
        Products = 1,
        ADs = 2,
        Other = 3
    }
}