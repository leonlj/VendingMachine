﻿using OWVendorMachineHub.Portal.Db;
using OWVendorMachineHub.Portal.Db.Models;
using OWVendorMachineHub.Portal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;

namespace OWVendorMachineHub.Portal.Controllers
{
    public class ProductManageController : OWVendorMachineHubControllerBase
    {
        // GET: Product
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Products(BootGridPagerModel model, string t = null, string k = "")
        {
            GridViewModel<ProductInfo> userData = new GridViewModel<ProductInfo> { current = model.current, rowCount = model.rowCount, total = 0, rows = null };

            using (ApplicationDbContext context = new ApplicationDbContext())
            {
                var q = context.ProductInfoes.Where(d => d.flag == "1");
                if (t == "id" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.skuId == k);
                }
                else if (t == "name" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.productName.Contains(k));
                }
                else if (t == "size" && !string.IsNullOrEmpty(k))
                {
                    q = q.Where(d => d.productSize == k);
                }

                userData.total = q.Count();
                userData.rows = q.OrderByDescending(d => d.skuId).Skip(userData.rowCount * (userData.current - 1)).Take(userData.rowCount).ToList();
            }

            return Json(userData);
        }

        [HttpGet]
        public ActionResult NewProduct()
        {
            return View();
        }

        [HttpPost]
        public ActionResult NewProduct(ProductInfo model)
        {
            if (ModelState.IsValid)
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var product = model;
                    product.skuId = DateTime.UtcNow.ToString("yyyyMMddHHmmss");
                    context.ProductInfoes.Add(product);
                    if (context.SaveChanges() > 0)
                    {
                        return OWRedirectResult.Redirect("/ProductManage/");
                    }
                    else
                    {
                        AddErrors(new AppDoResult("添加新产品失败，请重试！"));
                    }
                }
            }
            return View();
        }


        [HttpGet]
        public ActionResult EditProduct(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                ViewBag.ErrorMessage = "产品不存在！";
            }
            else
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var product = context.ProductInfoes.FirstOrDefault(d => d.flag == "1" && d.skuId == id);
                    if (product != null)
                    {
                        return View(product);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "产品不存在！";
                    }
                }
            }
            return View();
        }

        [HttpPost]
        public ActionResult EditProduct(ProductInfo model)
        {
            if (ModelState.IsValid)
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var product = context.ProductInfoes.FirstOrDefault(d => d.skuId == model.skuId);
                    if (product == null)
                    {
                        AddErrors(new AppDoResult("编辑设备失败，设备不存在！"));
                    }
                    else
                    {

                        product.productName = model.productName;
                        product.productDes = model.productDes;
                        product.listPrice = model.listPrice;
                        product.productSize = model.productSize;
                        product.productImageUrl = model.productImageUrl;

                        if (context.SaveChanges() > 0)
                        {
                            var channels = context.VMDeviceChannelInfoes.Include(c => c.DeviceInfo).Include(c => c.ProductInfo).Where(d => d.DeviceInfo.flag == "1" && d.skuId == product.skuId && d.DeviceInfo.flag == "1").ToArray();

                            if (channels != null && channels.Length > 0)
                            {
                                foreach (var item in channels)
                                {
                                    if (item.ProductInfo != null)
                                    {
                                        item.listPrice = item.ProductInfo.listPrice;
                                        item.productImageUrl = item.ProductInfo.productImageUrl;
                                        item.skuName = item.ProductInfo.productName;
                                    }
                                }
                                UpdateChannelInfoToCloud(channels);
                            }


                            return OWRedirectResult.Redirect("/ProductManage/");
                        }
                        else
                        {
                            AddErrors(new AppDoResult("保存产品信息失败，请重试！"));
                        }
                    }
                }
            }
            return View(model);
        }



        [HttpPost]
        public ActionResult Delete(string id)
        {

            AjaxResult result = new AjaxResult { Status = -1, Message = "删除产品失败！" };

            if (!string.IsNullOrEmpty(id))
            {
                using (ApplicationDbContext context = new ApplicationDbContext())
                {
                    var device = context.ProductInfoes.FirstOrDefault(d => d.flag == "1" && d.skuId == id);
                    if (device != null)
                    {
                        device.flag = "0";
                        if (context.SaveChanges() > 0)
                        {
                            result.Status = 1;
                            result.Message = "ok";
                        }
                    }
                    else
                    {
                        result.Message = " 删除失败，产品不存在！";
                    }
                }
            }
            return Json(result);
        }
    }
}