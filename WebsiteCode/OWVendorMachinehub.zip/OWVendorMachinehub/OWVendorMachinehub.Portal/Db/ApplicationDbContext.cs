﻿using Microsoft.AspNet.Identity.EntityFramework;
using OWVendorMachineHub.Portal.Db.Models;
using OWVendorMachineHub.Portal.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Db
{
    public class ApplicationDbContext : IdentityDbContext<UserInfo, RoleInfo, string, IdentityUserLogin, UserRole, IdentityUserClaim>
    {

        public IDbSet<UserRole> UserRoles { get; set; }

        public IDbSet<VMDeviceInfo> VMDeviceInfoes { get; set; }
        public IDbSet<VMDeviceChannelInfo> VMDeviceChannelInfoes { get; set; }
        public IDbSet<VMStatusRecord> VMStatusRecords { get; set; }
        public IDbSet<ProductInfo> ProductInfoes { get; set; }
        public IDbSet<ContactInfo> ContactInfoes { get; set; }
        public IDbSet<TransactionRecord> TransactionRecords { get; set; }
        public IDbSet<AddProductsRecord> AddProductRecords { get; set; }
        public IDbSet<AdvertisementInfo> AdvertisementInfoes { get; set; }


        public ApplicationDbContext()
            : base("OWVMDbConnection")
        {

        }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }
    }
}