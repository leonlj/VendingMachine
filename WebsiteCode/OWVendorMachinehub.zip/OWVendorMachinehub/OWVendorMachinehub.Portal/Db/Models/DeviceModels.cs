﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace OWVendorMachineHub.Portal.Db.Models
{
    [Table("VMDeviceInfo")]
    public class VMDeviceInfo
    {
        [Key]
        public string deviceId { get; set; }
        public string deviceType { get; set; }
        public string province { get; set; }
        public string city { get; set; }
        public string district { get; set; }
        public string deviceAddress { get; set; }
        public int channelNo { get; set; }
        public string contactId { get; set; }

        [ForeignKey("contactId")]
        public ContactInfo Contact { get; set; }
        public string advId { get; set; }

        [ForeignKey("advId")]
        public AdvertisementInfo AD { get; set; }
        public string healthFlag { get; set; }
        public string flag { get; set; }

        public VMDeviceInfo()
        {
            deviceType = DeviceType.NORMAL.ToString();
            healthFlag = null;
            flag = "1";
        }

    }

    public enum DeviceType
    {
        NORMAL = 1,
        COOLER = 2,
        OTHER = 3
    }

    public enum HealthStatus
    {
        HEALTH = 1,
        ALERT = 2,
        DOWN = 3
    }


    [Table("VMDeviceChannelInfo")]
    public class VMDeviceChannelInfo
    {
        [Key, Column(Order = 0)]
        public string deviceId { get; set; }
        [Key, Column(Order = 1)]
        public string channelId { get; set; }

        [ForeignKey("deviceId")]
        public VMDeviceInfo DeviceInfo { get; set; }


        public string skuId { get; set; }

        [ForeignKey("skuId")]
        public ProductInfo ProductInfo { get; set; }

        public string skuName { get; set; }
        public string productImageUrl { get; set; }
        public decimal listPrice { get; set; }
        public decimal discountPrice { get; set; }
    }

    [Table("VMStatusRecords")]
    public class VMStatusRecord
    {
        [Key, Column(Order = 0)]
        public string deviceId { get; set; }
        [Key, Column(Order = 1)]
        public DateTime addDate { get; set; }
        public string temperature { get; set; }
        public double voltDrop { get; set; }
        public double powerDraw { get; set; }
        public double dutyCycle { get; set; }
        public string healthFlag { get; set; }
    }

    [Table("ProductInfo")]
    public class ProductInfo
    {
        [Key]
        public string skuId { get; set; }
        public string productName { get; set; }
        public string productSize { get; set; }
        public string productDes { get; set; }
        public decimal listPrice { get; set; }
        public string productImageUrl { get; set; }
        public string flag { get; set; }
        public ProductInfo()
        {
            flag = "1";
        }
    }

    [Table("AddProductsRecords")]
    public class AddProductsRecord
    {
        [Key, Column(Order = 0)]
        public string deviceId { get; set; }
        [Key, Column(Order = 1)]
        public string channelId { get; set; }
        [Key, Column(Order = 2)]
        public string skuId { get; set; }
        [Key, Column(Order = 3)]
        public DateTime addTime { get; set; }
        public int addProductNo { get; set; }
    }

    [Table("TransactionRecords")]
    public class TransactionRecord
    {
        [Key, Column(Order = 0)]
        public string deviceId { get; set; }
        [Key, Column(Order = 1)]
        public string channelId { get; set; }
        [Key, Column(Order = 2)]
        public string skuId { get; set; }
        [Key, Column(Order = 3)]
        public string payBatchNo { get; set; }
        public int countNo { get; set; }
        public decimal payFee { get; set; }
        public string payType { get; set; }
        public DateTime transactionTime { get; set; }
    }

    [Table("ContactInfo")]
    public class ContactInfo
    {
        [Key]
        public string contactId { get; set; }
        public string contactName { get; set; }
        public string contactEmail { get; set; }
        public string contactPhone { get; set; }
        public string company { get; set; }
        public string others { get; set; }
        public string flag { get; set; }

        public ContactInfo()
        {
            flag = "1";
        }
    }

    [Table("AdvertisementInfo")]
    public class AdvertisementInfo
    {
        [Key]
        public string advId { get; set; }
        public string advType { get; set; }
        public string contentUrl { get; set; }
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
        public string flag { get; set; }

        public AdvertisementInfo()
        {
            flag = "1";
        }
    }


    public enum PayType
    {
        CASH,
        PASS,
        WECHAT
    }

    public enum ADType
    {
        PIC,
        VIDEO,
        OTHER
    }
}