﻿using System.Data.Entity;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OWVendorMachineHub.Portal.Db.Models
{
    // You can add profile data for the user by adding more properties to your ApplicationUser class, please visit http://go.microsoft.com/fwlink/?LinkID=317594 to learn more.
    public class UserInfo : IdentityUser<string, IdentityUserLogin, UserRole, IdentityUserClaim>
    {

        public string TrueName { get; set; }
        public string Address { get; set; }
        public string WeChatId { get; set; }
        public string Signature { get; set; }

        public UserStatus UserStatus { get; set; }

        public DateTime CreateTime { get; set; }
        public string CreateUser { get; set; }

        public DateTime UpdateTime { get; set; }
        public string UpdateUser { get; set; }

        public bool IsDelete { get; set; }


        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<UserInfo> manager)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            // Add custom user claims here
            return userIdentity;
        }
    }
  
    public enum UserStatus
    {
        UnActivated = 0,
        Activated = 1
    }



    public class UserRole : IdentityUserRole<string>
    {

    }





    public class RoleInfo : IdentityRole<string, UserRole>, IRole<string>
    {
        public int Level { get; set; }

        public RoleInfo() : base() { }
        public RoleInfo(string name)
            : this()
        {
            this.Name = name;
        }


    }

}