﻿$(function () {
    $(".content-head-nav ul li").eq(4).addClass("content-head-navys").children(".top-arrow").show();
    $(".content-head-nav ul li").click(function (e) {
        $(".top-arrow").hide();
        $(this).addClass("content-head-navys").children(".top-arrow").show().parent().siblings().removeClass("content-head-navys");
    });
});

var mySwiper = new Swiper('.swiper-container', {
    autoplay: 3000,
    speed: 1000,
    slidesPerView: 3,
    autoplayDisableOnInteraction: false,
    freeModeMomentumBounceRatio: 0,
    prevButton: '.swiper-button-prev',
    nextButton: '.swiper-button-next',
    effect: 'coverflow',
    coverflow: {
        rotate: 25,
        stretch: 0,
        depth: 60,
        modifier: 2,
        slideShadows: false
    },
    paginationClickable: true,
    loop: true,

});