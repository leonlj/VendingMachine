﻿$("#grid-data").bootgrid({
    rowCount: window.defaultBootGridRowCount,
    ajax: true,
    post: function () {
        /* To accumulate custom parameter with the request object */
        return {

        };
    },
    url: "/usermanage/users",
    formatters: {
        "operation": function (column, row) {
            return '<a href="javascript:;" class="disable-button"  data-user-id="' + row.UserId + '"  data-status ="' + row.IsDelete + '"  onclick="forbiddenClick(this)">'
                + (row.IsDelete == 0 ? '<span>禁用</span></a>' : '<span>启用</span></a>')
                + '<a href="javascript:;" class="edit-button" data-toggle="modal" data-target="#mymodal-Edit" data-user-id="' + row.UserId + '" onclick="editClick(this)" >'
                + '<span>编辑</span></a>';
        },
        "status": function (column, row) {
            return '<span class="col-user-status">' + row.Status + '</span>';
        }

    }

}).on("loaded.rs.jquery.bootgrid", function () {
    insertTd();
    $(".no-more-tables .edit-button").parent().css({ "padding": "0px" });
    //$("table.responsive th:nth-child(-n+3)").addClass("unstudied");
    //$("table.responsive td:nth-child(-n+3)").addClass("unstudied");
});




function insertTd() {
    var InsertLocation = $("table.table tbody tr td:last-child");
    $("<td class='addlast'><a href='javascript:;' class='detailinfo' onclick='detailClick(this)'>详细信息</a></td>").insertAfter(InsertLocation);
}

var positionTop = 0;
function detailClick(link) {
    var bodyHeight = $(window).height();
    positionTop = document.body.scrollTop;
    var orderTr = $(link).parents("tr").attr("data-row-id");
    $("#detail-info .table tbody tr").html($(link).parents("tr").html());
    //$("#detail-info").modal();
    $("#detail-info").css("display", "block").addClass("in");
    $(".modalbg").css({ "display": "block" }).animate({ "opacity": '0.5' });
    $("body").css({ "height": bodyHeight + "px", "overflow": "hidden" });
}
$(document).on("click", "#detail-info  button", function () {
    $("body").css({ "height": "auto", "overflow": "auto" });
    $("#detail-info").css("display", "none").removeClass("in");
    $(".modalbg").css("display", "none").animate({ "opacity": '0' });
    document.body.scrollTop = positionTop;
});

$(document).on("change", "#userRoles input[type='checkbox']", function () {
    var roles = "";
    $("#userRoles input[type='checkbox']:checked").each(function () {
        roles += $(this).val() + ",";
    });
    var inputRoles = $("input[name='Roles']").val(roles);
});


function editClick(link) {
    var target = $(link).attr("data-target");
    var userId = $(link).attr("data-user-id");

    openModalFromRemote(target, '/Account/EditUser?userId=' + userId);
}



function forbiddenClick(link) {

    var status = $(link).attr("data-status");
    var userId = $(link).attr("data-user-id");

    var url = status == 1 ? "/UserManage/Enable" : "/UserManage/Disable";

    $.ajax({
        url: url,
        method: 'post',
        datatype: 'json',
        data: { userId: userId },
        success: function (data) {
            if (data != null) {
                if (data.Status >= 0) {
                    setUserStatus(link, status == 1 ? 0 : 1);
                }
                alert(data.Message);
            }
        },
        error: function () {
            alert("操作失败！");
        }
    });
}

function setUserStatus(link, status) {
    $(link).attr("data-status", status).find("span").text(status == 1 ? "启用" : "禁用");
    $(link).parents("tr").find(".col-user-status").text(status == 1 ? "已禁用" : "已启用");
}


$("#btnAddUser").on("click", function (e) {
    openModalFromRemote($(this).attr("data-target"), '/Account/AddUser');
});


new AjaxForm({ Target: '#changepersonal', ResultContainer: '#mymodal-Edit' });
new AjaxForm({ Target: '#addpersonal', ResultContainer: '#mymodal-data' });