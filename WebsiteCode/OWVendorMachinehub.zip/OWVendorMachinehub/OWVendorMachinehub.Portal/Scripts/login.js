$(function (e) {
    //����
    topnav();
    function topnav() {
        var signurl = window.location.href;
        var pageNum = 0;
        var index = signurl.lastIndexOf("#");
        if (index > 0) {
            try {
                pageNum = parseInt(signurl.substr(index + 1, signurl.length));

            } catch (e) {

            }
        }
        if (pageNum > 0) {
            $("#SubpageBanner ul.nav-tabs li").removeClass("active");
            $("#SubpageBanner ul.nav-tabs li:nth-child(" + pageNum + ")").addClass("active");
            $("#SubpageBanner .tab-content .tab-pane").removeClass("active in");
            $("#SubpageBanner .tab-content .tab-pane:nth-child(" + pageNum + ")").addClass("active in");
            $(".left-img img").attr("src", "/img/signin/signin-banner" + pageNum + ".png");
        }

    }
    $("#topNav #signinMain li").on("click", function () {
        location.reload();
    });
    var $btns = $("#myTab li");
    $btns.click(function (e) {
        e.preventDefault();
        var bg = $(this).index() + 1;
        window.location.href = "#sign" + "#" + bg;
        $(".left-img img").attr("src", "/img/signin/signin-banner" + bg + ".png");
    });


})