﻿$(function () {
    var path = window.location.pathname;
    $(".nav-list li a[href='" + path + "']").addClass("navys");
});