﻿$(function () {
    //console.log("test");
    //alert("test");

    (function bindEvents() {
        $(document).on("change", "#userRoles .checkbox", userRolesChanged);
    })();


    function userRolesChanged(e) {
        if (_showProviderList) {

            var checked = false;

            $("#userRoles .checkbox").each(function () {
                var label = getLabel($(this));
                if (label == "销售人员" || label == "管理员") {
                    if ($(this).is(":checked")) {
                        checked = true;
                    }
                }
            });

            if (checked) {
                $(this).parents("form").find("#UserProviderGroup").show();
            } else {
                $(this).parents("form").find("#UserProviderGroup").hide();
            }
        }
    }


    function getLabel(selector) {
        return selector.parent().find("label[for='role-" + selector.val() + "']").text();
    }


    (function getProviders() {
        $.ajax({
            url: '/account/getuserproviders',
            type: 'post',
            success: function (data) {
                if (data != null && data.Data != null && data.Status > 0) {
                    loadProviders(data.Data);
                }
            }
        });
    })();

    function loadProviders(data) {
        var providerList = $(".providers").html("");
        for (var i = 0; i < data.length; i++) {
            providerList.append('<option value="' + data[i].ProviderId + '">' + data[i].ProviderName + '</option>');
        }

        selectProviders("#UserProviders");
    }


    function selectProviders(selector) {
        //console.log("edituser");
        //alert("edituser");
        var providers = $(selector);
        var values = providers.attr("data-value");
        if (values != null && values != "") {
            providers.val(values);
            if (_showProviderList)
                providers.parent().show();
            else
                providers.parent().hide();
        } else {
            providers.parent().hide();
        }
    }
});