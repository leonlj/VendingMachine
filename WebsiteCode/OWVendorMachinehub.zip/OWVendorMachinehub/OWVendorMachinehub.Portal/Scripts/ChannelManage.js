﻿$("#grid-data").bootgrid({
    rowCount: window.defaultBootGridRowCount,
    ajax: true,
    post: function () {
        /* To accumulate custom parameter with the request object */
        return {
            t: $("select[name='t']").val(),
            k: $("input[name='k']").val()
        };
    },
    url: "/channelmanage/channels",
    formatters: {
        "operation": function (column, row) {
            return '<i class="glyphicon glyphicon-pencil btn" data-toggle="modal" data-target="#mymodal-Edit"  data-channel-id="' + row.channelId + '"  data-device-id="' + row.deviceId + '" onclick="editClick(this)" ></i>';
        },
        "image": function (column, row) {
            if (row.skuId == null)
                return "";
            return '<a href="' + row.productImageUrl + '"  taget="_blank"><img src="' + row.productImageUrl + '" class="product-img"/></a>';
        }
    }

}).on("loaded.rs.jquery.bootgrid", function () {
    insertTd();
    $(".no-more-tables .edit-button").parent().css({ "padding": "0px" });
});


function reload() {
    $("#grid-data").bootgrid("reload");
}

$("#btnRefresh").on("click", function () {
    reload();
});

$("#btnSearch").on("click", function () {
    reload();
});


function insertTd() {
    var InsertLocation = $("table.table tbody tr td:last-child");
    $("<td class='addlast'><a href='javascript:;' class='detailinfo' onclick='detailClick(this)'>详细信息</a></td>").insertAfter(InsertLocation);
}

var positionTop = 0;
function detailClick(link) {
    var bodyHeight = $(window).height();
    positionTop = document.body.scrollTop;
    var orderTr = $(link).parents("tr").attr("data-row-id");
    $("#detail-info .table tbody tr").html($(link).parents("tr").html());
    //$("#detail-info").modal();
    $("#detail-info").css("display", "block").addClass("in");
    $(".modalbg").css({ "display": "block" }).animate({ "opacity": '0.5' });
    $("body").css({ "height": bodyHeight + "px", "overflow": "hidden" });
}
$(document).on("click", "#detail-info  button", function () {
    $("body").css({ "height": "auto", "overflow": "auto" });
    $("#detail-info").css("display", "none").removeClass("in");
    $(".modalbg").css("display", "none").animate({ "opacity": '0' });
    document.body.scrollTop = positionTop;
});


function editClick(link) {
    var target = $(link).attr("data-target");
    var channelId = $(link).attr("data-channel-id");
    var deviceId = $(link).attr("data-device-id");

    openModalFromRemote(target, '/ChannelManage/EditChannel?id=' + channelId + "&deviceId=" + deviceId);
}

new AjaxForm({ Target: '#editChannel', ResultContainer: '#mymodal-Edit' });