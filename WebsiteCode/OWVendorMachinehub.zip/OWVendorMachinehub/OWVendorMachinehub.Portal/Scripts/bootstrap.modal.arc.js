﻿function openModalFromRemote(targetModal, dataUrl, callback) {
    //$.get(dataUrl, 'r=' + Math.random(), function (data) {
    //    $(targetModal).html(data);
    //    if (callback != null) {
    //        callback();
    //    }
    //});
    $(".loadimg").css({ "display": "block" });
    $.ajax({
        url: dataUrl,
        type: 'get',
        data: { r: Math.random() },
        success: function (data) {
            $(".loadimg").css({ "display": "none" });
            $(targetModal).html('').modal({ show: true, backdrop: "static" });
            if (data.Status != null) {
                if (data.Status == 302) {
                    window.location.href = data.RedirectUrl;
                } else if (data.Status == 303) {
                    location.reload();
                }
            } else {
                $(targetModal).html(data);
            }

            if (callback != null) {
                callback();
            }
        },
        error: function () {
            $(".loadimg").css({ "display": "none" });
            alert("请求提交失败！");
        }
    });
}