﻿$("#grid-data").bootgrid({
    rowCount: window.defaultBootGridRowCount,
    ajax: true,
    post: function () {
        /* To accumulate custom parameter with the request object */
        return {
            t: $("select[name='t']").val(),
            k: $("input[name='k']").val()
        };
    },
    url: "/devicestatusmanage/list",
    formatters: {
        "healthFlag": function (column, row) {
            if (row.healthFlag == "HEALTH") {
                return "健康";
            } else if (row.healthFlag == "DOWN") {
                return "下降";
            } else if (row.healthFlag == "ALERT") {
                return "报警";
            }
        },
        "date": function (column, row) {
            return jsonDateFormat(row.addDate);
        }
    }

}).on("loaded.rs.jquery.bootgrid", function () {
    insertTd();
    $(".no-more-tables .edit-button").parent().css({ "padding": "0px" });
});


function reload() {
    $("#grid-data").bootgrid("reload");
}

$("#btnRefresh").on("click", function () {
    reload();
});

$("#btnSearch").on("click", function () {
    reload();
});


function insertTd() {
    var InsertLocation = $("table.table tbody tr td:last-child");
    $("<td class='addlast'><a href='javascript:;' class='detailinfo' onclick='detailClick(this)'>详细信息</a></td>").insertAfter(InsertLocation);
}

var positionTop = 0;
function detailClick(link) {
    var bodyHeight = $(window).height();
    positionTop = document.body.scrollTop;
    var orderTr = $(link).parents("tr").attr("data-row-id");
    $("#detail-info .table tbody tr").html($(link).parents("tr").html());
    //$("#detail-info").modal();
    $("#detail-info").css("display", "block").addClass("in");
    $(".modalbg").css({ "display": "block" }).animate({ "opacity": '0.5' });
    $("body").css({ "height": bodyHeight + "px", "overflow": "hidden" });
}
$(document).on("click", "#detail-info  button", function () {
    $("body").css({ "height": "auto", "overflow": "auto" });
    $("#detail-info").css("display", "none").removeClass("in");
    $(".modalbg").css("display", "none").animate({ "opacity": '0' });
    document.body.scrollTop = positionTop;
});

function jsonDateFormat(jsonDate) {
    try {
        var date = new Date(parseInt(jsonDate.replace("/Date(", "").replace(")/", ""), 10));
        var month = date.getMonth() + 1 < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
        var day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var seconds = date.getSeconds();
        var milliseconds = date.getMilliseconds();
        return date.getFullYear() + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;
    } catch (ex) {
        return "";
    }
}