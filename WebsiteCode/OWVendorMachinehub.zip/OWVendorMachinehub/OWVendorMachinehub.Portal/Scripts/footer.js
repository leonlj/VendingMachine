$(function(){
	 $(".footer-content ul li").hover(function(e) {
        $(this).children(".footer-float").animate({height:0},100);
		$(this).children(".footer-center").addClass("footer-contentys");
		var srcx=$(this).children(".footer-center").children(".img").children("img").attr("src").split(".");
		$(this).children(".footer-center").children(".img").children("img").attr("src",srcx[0]+"ys."+srcx[1]);
    },function(){
		var a=$(this).index()+1;
		$(this).children(".footer-float").animate({height:10},100);
		$(this).children(".footer-center").removeClass("footer-contentys");
		$(this).children(".footer-center").children(".img").children("img").attr("src","/images/footer"+a+".png")
		});
	 });