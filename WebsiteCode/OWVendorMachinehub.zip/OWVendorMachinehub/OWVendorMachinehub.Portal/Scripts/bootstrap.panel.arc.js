﻿
function LoadPanelFromRemote(options) {
    var _panelSelector = options.Panel;
    var _dataSource = options.Url;
    var _title = options.Title;
    var _style = options.Style;
    var _loadComplted = options.LoadComplted;

    var panel = $(_panelSelector);
    if (_title != null)
        panel.find(".panel-title").text(_title);
    if (_style != null)
        panel.removeClass().addClass("panel").addClass(_style);
    if (_dataSource != null) {
        //$.get(_dataSource, 'r='+Math.random(), function (data) {
        //    $(_panelSelector).find(".panel-body").html(data);

        //    if (_loadComplted) {
        //        _loadComplted();
        //    }
        //})

        $(".loadimg").css({ "display": "block" });
        $.ajax({
            url: _dataSource,
            type: 'get',
            data: { r: Math.random() },
            success: function (data) {
                $(".loadimg").css({ "display": "none" });
                if (data.Status != null) {
                    if (data.Status == 302) {
                        window.location.href = data.RedirectUrl;
                    } else if (data.Status == 303) {
                        location.reload();
                    }
                } else {
                    $(_panelSelector).find(".panel-body").html(data);
                }

                if (_loadComplted) {
                    _loadComplted();
                }
            },
            error: function (e) {
                $(".loadimg").css({ "display": "none" });
                alert("请求提交失败！");
            }
        });


    }
}


