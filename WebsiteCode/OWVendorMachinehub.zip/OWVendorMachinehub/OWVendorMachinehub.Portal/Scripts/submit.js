$(function () {
    /*第一屏*/

    $(".submit-button-one").on("click", function () {
        $("#formBasicInfo").submit();
    });

    $("#formBasicInfo").on("submit", function (e) {
        var Name = $("#name").val();
        var Mailbox = $("#mailbox").val();
        var phone = $("#phone").val();
        var CompanyName = $("#companyname").val();
        var Nametwo = $("#nametwo").val();
        var Mailboxtwo = $("#mailboxtwo").val();
        var phonetwo = $("#phonetwo").val();
        var CompanyNametwo = $("#companynametwo").val();
        var msgs = "";
        var reg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
        var myreg = /^1\d{10}$/;

        if (Name == "") {
            msgs += '请输入营销商姓名！\n';
        }
        if (!reg.test(Mailbox)) {
            msgs += '请输入正确的营销商邮箱地址！\n';
        }
        if (!myreg.test(phone)) {
            msgs += '请输入有效的营销商手机号码！\n';
        }
        if (CompanyName == "") {
            msgs += '请输入营销商公司地址！\n';
        }
        if (Nametwo == "") {
            msgs += '请输入客户姓名！\n';
        }
        if (!reg.test(Mailboxtwo)) {
            msgs += '请输入正确的客户邮箱地址！\n';
        }
        if (!myreg.test(phonetwo)) {
            msgs += '请输入有效的客户手机号码！\n';
        }
        if (CompanyNametwo == "") {
            msgs += '请输入客户公司地址！\n';
        }
        if (msgs != "") {
            alert(msgs);
            return false;
        }
        else {
            $(".content ul li").hide();
            $(".content ul li").eq(1).show();
            $(".button ul li").eq(1).addClass("buttonys");
        }
    });
   
});