$(function (e) {
    var inncontent = $(".content h5").text();   
    if (inncontent == $("ul.submenu li:nth-child(1) a").text()) {
        $("ul.submenu li").removeClass("active");
        $("ul.submenu li:nth-child(1)").addClass("active");
    } else if (inncontent == $("ul.submenu li:nth-child(2) a").text()) {
        $("ul.submenu li").removeClass("active");
        $("ul.submenu li:nth-child(2)").addClass("active");
    };
});

if ($(".navbar-toggle").css("display") == "block") {
    var $div1 = $("#mainReport");
    var $div3 = $("#AwardList");
    var $temobj1 = $("<div></div>");
    var $temobj2 = $("<div></div>");
    $temobj1.insertBefore($div1);
    $temobj2.insertBefore($div3);
    $div1.insertAfter($temobj2);
    $div3.insertAfter($temobj1);
    $temobj1.remove();
    $temobj2.remove();
}



$(window).on("resize", changeEvent);
function changeEvent() {
     if ($(".navbar-toggle").css("display") == "none") {
        $('#sidebar-nav').css({ left: 'auto' });
        $('.main-part .sidebar-bg').css({ "display": "none" });
        $("body").css({ "height": "auto", "overflow": "auto" });
    } else {
         $('#sidebar-nav').css({ left: '-240px' });
         $('.main-part .sidebar-bg').css({ "display": "none" });
         $("body").css({ "height": "auto", "overflow": "auto" });
      }
}

leftNav();
function leftNav() {
    var bodyHeight = $(window).height();
    var isHiden = true;	/*�����л��˵�*/
    if (window.hasOwnProperty("ontouchstart") || document.hasOwnProperty("ontouchstart")) {
        if (navigator.userAgent.indexOf('Windows Phone') > -1) {//winphone�ֻ�
            $(document).on("pointerdown", ".navbar-inverse .listbutton", function (e) {
                e.preventDefault();
                if (isHiden) {
                    $('#sidebar-nav').animate({ left: '0px' });
                    $('.main-part .sidebar-bg').css({ "display": "block" }).animate({ "opacity": '0.5' });
                    $("body").css({ "height": bodyHeight + "px", "overflow": "hidden" });
                } else {
                    $('#sidebar-nav').animate({ left: '-240px' });
                    $('.main-part .sidebar-bg').css({ "display": "none" }).animate({ "opacity": '0' });
                    $("body").css({ "height": "auto", "overflow": "auto" });
                }
                isHiden = !isHiden;
            });
        }else{
            $(document).on("touchstart", ".navbar-inverse .listbutton", function (e) {
                e.preventDefault();
                if (isHiden) {
                    $('#sidebar-nav').animate({ left: '0px' });
                    $('.main-part .sidebar-bg').css({ "display": "block" }).animate({ "opacity": '0.5' });
                    $("body").css({ "height": bodyHeight + "px", "overflow": "hidden" });
                } else {
                    $('#sidebar-nav').animate({ left: '-240px' });
                    $('.main-part .sidebar-bg').css({ "display": "none" }).animate({ "opacity": '0' });
                    $("body").css({ "height": "auto", "overflow": "auto" });
                }
                isHiden = !isHiden;
            });
        }
    }else{
        $(document).on("mousedown", ".navbar-inverse .listbutton", function (e) {
            e.preventDefault();
            if (isHiden) {
                $('#sidebar-nav').animate({ left: '0px' });
                $('.main-part .sidebar-bg').css({ "display": "block" }).animate({ "opacity": '0.5' });
                $("body").css({ "height": bodyHeight + "px", "overflow": "hidden" });
            } else {
                $('#sidebar-nav').animate({ left: '-240px' });
                $('.main-part .sidebar-bg').css({ "display": "none" }).animate({ "opacity": '0' });
                $("body").css({ "height": "auto", "overflow": "auto" });
            }
            isHiden = !isHiden;
        });
   }
}
$(document).on("mouseover", "a.followstatus", function () {
    var spanWidth = $(this).children('span').width();
    $(this).removeClass("txtellipss")
    $(this).children().animate({ marginLeft: (0 - spanWidth) }, 5000, function () {
        $(this).animate({ marginLeft: (0) }, 5000);
        });
});
$(document).on("mouseout", "a.followstatus", function () {
    $(this).addClass("txtellipss");
    $(this).children().stop().css({ marginLeft: (0) });

});
