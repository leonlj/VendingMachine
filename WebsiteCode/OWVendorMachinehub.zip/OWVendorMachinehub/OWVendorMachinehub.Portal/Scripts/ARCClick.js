﻿function BindARCClick(target, func, selector) {
    if (window.hasOwnProperty("ontouchstart") || document.hasOwnProperty("ontouchstart")) {
        if (selector == null) {
            $(target).on("touchstart", function (e) {
                func($(this));
            });
        } else {
            $(target).on("touchstart", selector, function (e) {
                func($(this));
            });
        }
    } else {
        if (selector == null) {
            $(target).on("click", function (e) {
                func($(this));
            });
        } else {
            $(target).on("click", selector, function (e) {
                func($(this));
            });
        }
    }
}

