﻿function FileUploader(option) {

    var _source = option.Source;
    var _target = option.Target;
    var _complted = option.Complted;
    var _maxSize = option.MaxSize ? option.MaxSize : 5120000;
    var _types = option.Types == null ? [] : option.Types;
    var _onStart = option.OnStart;
    var _autoUpload = option.AutoUpload == null ? true : option.AutoUpload;
    var _file;

    var fileInput = document.getElementById(_source);
    fileInput.onchange = function (e) {
        if (_autoUpload) {
            startUpload();
        }
    }

    this.start = startUpload;

    function startUpload() {
        _file = document.getElementById(_source).files[0];

        if (!verifyFileType(_file.type)) {
            complete({ Status: -1, Message: "请上传指定类型的文件" });
        }
        else {
            if (_file.size > _maxSize) {
                complete({ Status: -1, Message: "文件大小超过限制" });
            } else {
                var reader = new FileReader();
                reader.onload = onload;
                reader.onerror = onerror;
                //reader.onloadend = onloadend;
                reader.onloadstart = onloadstart;
                reader.readAsDataURL(_file);
            }
        }
    }

    function verifyFileType(fileType) {
        if (_types.length <= 0)
            return true;
        for (var i = 0; i < _types.length; i++) {
            if (fileType.indexOf(_types[i]) >= 0) {
                return true;
            }
        }
        return false;
    }

    function onload() {
        var result = this.result;
        var fileContent = result.replace(/^data\:(([^\;]+)\;)?base64,/gmi, "");
        $.ajax({
            url: _target,
            data: { fileContent: fileContent, fileName: _file.name, fileType: _file.type },
            type: 'post',
            dataType: 'json',
            success: function (data) {
                complete(data);
            },
            error: function (data) {
                complete({ Status: -1, Message: "上传失败！" });
            }
        });
    }


    function onerror() {
        complete({ Status: -1, Message: "failed", Data: this.result });
    }

    function onloadend() {
        complete({ Status: 1, Message: "OK", Data: this.result });
    }

    function onloadstart() {
        if (_onStart) {
            _onStart();
        }
    }


    function complete(data) {
        if (_complted) {
            document.getElementById(_source).value = "";
            _complted(data);
        }
    }
}