﻿$("#grid-data").bootgrid({
    rowCount: window.defaultBootGridRowCount,
    ajax: true,
    post: function () {
        /* To accumulate custom parameter with the request object */
        return {
            t: $("select[name='t']").val(),
            k: $("input[name='k']").val()
        };
    },
    url: "/productmanage/products",
    formatters: {
        "operation": function (column, row) {
            return '<i href="javascript:;" class="btn glyphicon glyphicon-pencil" data-toggle="modal" data-target="#mymodal-Edit" data-id="' + row.skuId + '" onclick="editClick(this)" ></i>'
            + '<i href="javascript:;" class="btn glyphicon glyphicon-trash"  data-id="' + row.skuId + '"    onclick="forbiddenClick(this)"></i>';
        },

        "image": function (column, row) {
            return '<a href="' + row.productImageUrl + '"  taget="_blank"><img src="' + row.productImageUrl + '" class="product-img"/></a>';
        }

    }

}).on("loaded.rs.jquery.bootgrid", function () {
    insertTd();
    $(".no-more-tables .edit-button").parent().css({ "padding": "0px" });
});


function reload() {
    $("#grid-data").bootgrid("reload");
}

$("#btnRefresh").on("click", function () {
    reload();
});

$("#btnSearch").on("click", function () {
    reload();
});


function insertTd() {
    var InsertLocation = $("table.table tbody tr td:last-child");
    $("<td class='addlast'><a href='javascript:;' class='detailinfo' onclick='detailClick(this)'>详细信息</a></td>").insertAfter(InsertLocation);
}

var positionTop = 0;
function detailClick(link) {
    var bodyHeight = $(window).height();
    positionTop = document.body.scrollTop;
    var orderTr = $(link).parents("tr").attr("data-row-id");
    $("#detail-info .table tbody tr").html($(link).parents("tr").html());
    //$("#detail-info").modal();
    $("#detail-info").css("display", "block").addClass("in");
    $(".modalbg").css({ "display": "block" }).animate({ "opacity": '0.5' });
    $("body").css({ "height": bodyHeight + "px", "overflow": "hidden" });
}
$(document).on("click", "#detail-info  button", function () {
    $("body").css({ "height": "auto", "overflow": "auto" });
    $("#detail-info").css("display", "none").removeClass("in");
    $(".modalbg").css("display", "none").animate({ "opacity": '0' });
    document.body.scrollTop = positionTop;
});


function editClick(link) {
    var target = $(link).attr("data-target");
    var userId = $(link).attr("data-id");

    openModalFromRemote(target, '/ProductManage/EditProduct?id=' + userId);
}



function forbiddenClick(link) {
    var deviceId = $(link).attr("data-id");

    var url = "/ProductManage/Delete";

    $.ajax({
        url: url,
        method: 'post',
        datatype: 'json',
        data: { id: deviceId },
        success: function (data) {
            if (data != null) {
                if (data.Status >= 0) {
                    alert("删除成功！");
                    reload();
                } else
                    alert(data.Message);
            }
        },
        error: function () {
            alert("操作失败！");
        }
    });
}


$("#btnAddDevice").on("click", function (e) {
    openModalFromRemote($(this).attr("data-target"), '/ProductManage/NewProduct');
});


new AjaxForm({ Target: '#editProduct', ResultContainer: '#mymodal-Edit' });
new AjaxForm({ Target: '#newProduct', ResultContainer: '#mymodal-Edit' });