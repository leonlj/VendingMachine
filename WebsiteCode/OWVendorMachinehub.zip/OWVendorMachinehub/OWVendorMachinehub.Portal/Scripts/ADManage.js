﻿$("#grid-data").bootgrid({
    rowCount: window.defaultBootGridRowCount,
    ajax: true,
    post: function () {
        /* To accumulate custom parameter with the request object */
        return {
            t: $("select[name='t']").val(),
            k: $("input[name='k']").val()
        };
    },
    url: "/admanage/list",
    formatters: {
        "operation": function (column, row) {
            return '<i href="javascript:;" class="btn glyphicon glyphicon-pencil" data-toggle="modal" data-target="#mymodal-Edit" data-id="' + row.advId + '" onclick="editClick(this)" ></i>'
            + '<i href="javascript:;" class="btn glyphicon glyphicon-trash"  data-id="' + row.advId + '"    onclick="forbiddenClick(this)"></i>';
        },
        "startDate": function (column, row) {
            return jsonDateFormat(row.startDate);
        },
        "endDate": function (column, row) {
            return jsonDateFormat(row.endDate);
        },
        "adType": function (column, row) {
            if (row.advType == "PIC")
                return "图片";
            else if (row.advType == "VIDEO")
                return "视频";
            else if (row.advType == "OTHER")
                return "其它";
        },
        "url": function (column, row) {
            return '<a href="' + row.contentUrl + '" target="_blank">' + row.contentUrl + '</a>';
        }
    }

}).on("loaded.rs.jquery.bootgrid", function () {
    insertTd();
    $(".no-more-tables .edit-button").parent().css({ "padding": "0px" });
});


function reload() {
    $("#grid-data").bootgrid("reload");
}

$("#btnRefresh").on("click", function () {
    reload();
});

$("#btnSearch").on("click", function () {
    reload();
});


function insertTd() {
    var InsertLocation = $("table.table tbody tr td:last-child");
    $("<td class='addlast'><a href='javascript:;' class='detailinfo' onclick='detailClick(this)'>详细信息</a></td>").insertAfter(InsertLocation);
}

var positionTop = 0;
function detailClick(link) {
    var bodyHeight = $(window).height();
    positionTop = document.body.scrollTop;
    var orderTr = $(link).parents("tr").attr("data-row-id");
    $("#detail-info .table tbody tr").html($(link).parents("tr").html());
    //$("#detail-info").modal();
    $("#detail-info").css("display", "block").addClass("in");
    $(".modalbg").css({ "display": "block" }).animate({ "opacity": '0.5' });
    $("body").css({ "height": bodyHeight + "px", "overflow": "hidden" });
}
$(document).on("click", "#detail-info  button", function () {
    $("body").css({ "height": "auto", "overflow": "auto" });
    $("#detail-info").css("display", "none").removeClass("in");
    $(".modalbg").css("display", "none").animate({ "opacity": '0' });
    document.body.scrollTop = positionTop;
});


function editClick(link) {
    var target = $(link).attr("data-target");
    var userId = $(link).attr("data-id");

    openModalFromRemote(target, '/ADManage/Edit?id=' + userId);
}



function forbiddenClick(link) {
    var deviceId = $(link).attr("data-id");

    var url = "/ADManage/Delete";

    $.ajax({
        url: url,
        method: 'post',
        datatype: 'json',
        data: { id: deviceId },
        success: function (data) {
            if (data != null) {
                if (data.Status >= 0) {
                    alert("删除成功！");
                    reload();
                } else
                    alert(data.Message);
            }
        },
        error: function () {
            alert("操作失败！");
        }
    });
}


$("#btnAdd").on("click", function (e) {
    openModalFromRemote($(this).attr("data-target"), '/ADManage/New');
});


new AjaxForm({ Target: '#newAD', ResultContainer: '#mymodal-Edit' });
new AjaxForm({ Target: '#editAD', ResultContainer: '#mymodal-Edit' });


function jsonDateFormat(jsonDate) {
    try {
        var date = new Date(parseInt(jsonDate.replace("/Date(", "").replace(")/", ""), 10));
        var month = date.getMonth() + 1 < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
        var day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var seconds = date.getSeconds();
        var milliseconds = date.getMilliseconds();
        return date.getFullYear() + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;
    } catch (ex) {
        return "";
    }
}