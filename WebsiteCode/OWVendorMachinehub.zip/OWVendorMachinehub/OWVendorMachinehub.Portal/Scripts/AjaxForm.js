﻿function AjaxForm(options) {
    var target = options.Target;
    var resultEle = options.ResultContainer;

    $(document).on("submit", target, function (e) {
        var action = $(this).attr("action");
        var data = $(this).serialize();
        $(".loadimg").css({ "display": "block" });
        console.log("action:" + action);
        console.log("data:" + data);

        $.ajax({
            url: action,
            datatype: 'json',
            type: 'post',
            data: data,
            success: function (data) {
                $(".loadimg").css({ "display": "none" });
                if (data.Status != null) {
                    if (data.Status == 302) {
                        window.location.href = data.RedirectUrl;
                        //alert(data.RedirectUrl);
                    } else if (data.Status == 303) {
                        location.reload();
                    }
                } else {
                    $(resultEle).html(data);
                }
            },
            error: function () {
                $(".loadimg").css({ "display": "none" });
                alert("请求提交失败！");
            }
        });
        return false;
    });
}